package demoblazePom;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ReusableFunctions;
import io.cucumber.java.cs.Ale;

public class Signup {
	WebDriver driver;
	WebDriverWait wait;
	ReusableFunctions rf;

	public Signup(WebDriver driver, ReusableFunctions rf) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		this.rf = rf;

	}

//	locate signup link on nav bar
	@FindBy(id = "signin2")
	WebElement singup;

//	singup user name text field
	@FindBy(id = "sign-username")
	WebElement username;

//	signup Password test field
	@FindBy(id = "sign-password")
	WebElement pwd;

//	singup button to click after credentials
	@FindBy(xpath = "//button[@onclick='register()']")
	WebElement singupButton;

//	cross button to close the singup box
	@FindBy(xpath = "//*[@id=\"signInModal\"]/div/div/div[1]/button/span")
	WebElement closeButton;

//	signup text in signup box. used to validate invalid signup
	@FindBy(id = "signInModalLabel")
	WebElement signupText;

//	signup model body
	@FindBy(className = "modal-body")
	WebElement signupModelBody;

//	Method will return signup text in singup box to validate invalid signup
//	user wont move to next page
	public String invalidSignup(String uname, String pwd) throws InterruptedException {
		rf.clickOnElement(singup);
		rf.waitForElementToDisplay(username);
		rf.setTextToInputField(username, uname);
		rf.setTextToInputField(this.pwd, pwd);
		rf.clickOnElement(singupButton);

		Thread.sleep(1000);
//		simple Alert handling
		Alert a = driver.switchTo().alert();
		a.accept();
//		rf.waitForElementToDisplay(closeButton);

		rf.clickOnElement(closeButton);

		return signupText.getText();

	}

	public boolean validSignup(String uname, String pwd) throws InterruptedException {
		rf.clickOnElement(singup);
		rf.waitForElementToDisplay(username);
		rf.setTextToInputField(username, uname);
		rf.setTextToInputField(this.pwd, pwd);
		rf.clickOnElement(singupButton);

		Thread.sleep(1000);
//		simple Alert handling
		Alert a = driver.switchTo().alert();
		a.accept();

		return signupModelBody.isDisplayed();

	}

}
