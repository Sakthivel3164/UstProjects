package demoblazePom;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ReusableFunctions;

public class AddToCartPom {
	WebDriver driver;
	WebDriverWait wait;
	ReusableFunctions rf;

	public AddToCartPom(WebDriver driver, ReusableFunctions rf) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		this.rf = rf;

	}

//	samsung galaxy mobile
	@FindBy(linkText = "Samsung galaxy s6")
	WebElement phone;
//	product description 
	@FindBy(id = "more-information")
	WebElement prod_desc;
//	Add to cart button
	@FindBy(linkText = "Add to cart")
	WebElement addToCartButton;

//	cart option in nav bar
	@FindBy(linkText = "Cart")
	WebElement cart;

//	product name inside cart
	@FindBy(xpath = "//tbody/tr/td[2]")
	WebElement cartProduct;

	public void clickItem() {
		rf.clickOnElement(phone);
	}

	public boolean isProductDescriptionDisplayed() {
		rf.waitForElementToDisplay(prod_desc);
		return prod_desc.isDisplayed();
	}

	public boolean isAddToCartShown() {
		rf.waitForElementToDisplay(addToCartButton);
		return addToCartButton.isDisplayed();
	}

	public void addItemToCart() throws InterruptedException {
		rf.clickOnElement(addToCartButton);
		Thread.sleep(1000);
		Alert a = driver.switchTo().alert();
		a.accept();

//		click on cart link on nav bar 
		rf.waitForElementToDisplay(cart);
		rf.clickOnElement(cart);

	}

	public String getItemName() {
		rf.waitForElementToDisplay(cartProduct);
		return cartProduct.getText();
	}

}
