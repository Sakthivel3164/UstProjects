package base;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class Report {
	ExtentSparkReporter htmlReporter;
	ExtentReports reports;
	ExtentTest test;
	@BeforeTest
	public void startReport() {
		htmlReporter = new ExtentSparkReporter("ExtentReportDemo.html");
		reports = new ExtentReports();
		reports.attachReporter(htmlReporter);
		// add environtment variables
		reports.setSystemInfo("OS", "Windows");
		reports.setSystemInfo("Browser", "chrome");
		reports.setSystemInfo("Environment", "QA");
		reports.setSystemInfo("user", "Sakthivel");
		// configuration look
		htmlReporter.config().setDocumentTitle("Extent Report Demo");
		htmlReporter.config().setReportName("Test Report");
		htmlReporter.config().setTheme(Theme.DARK);
		htmlReporter.config().setTimeStampFormat("EEE,MMM dd, yyyy, hh:mm a '('zzz')'");
	}

	@AfterMethod
	public void getTestResult(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			test.log(com.aventstack.extentreports.Status.FAIL,
					MarkupHelper.createLabel(result.getName() + " FAIL", ExtentColor.RED));
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			test.log(com.aventstack.extentreports.Status.PASS,
					MarkupHelper.createLabel(result.getName() + " PASS", ExtentColor.GREEN));
		} else if (result.getStatus() == ITestResult.SKIP) {
			test.log(com.aventstack.extentreports.Status.SKIP,
					MarkupHelper.createLabel(result.getName() + " SKIP", ExtentColor.YELLOW));
		}
	}
	@AfterTest
	public void tearDown()
	{
		reports.flush();
	}

}
