package base;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;

public class Screenshot {
	WebDriver driver;
	@AfterMethod
	private void takeScreenshot(ITestResult result) {
		String s = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				FileUtils.copyFile(screenshot,
						new File(System.getProperty("user.dir") + "/screenshot/" + s + ".jpg"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
