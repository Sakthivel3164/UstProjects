package testngTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;

import base.DriverSetup;
import base.ReusableFunctions;
import demoblazePom.Signup;
import excelHandling.ExcelHandling2;

public class TestDemoBlaze {
	WebDriver driver;
	ReusableFunctions rf;
	Signup signup;
	int screenShotCounter;

	@Parameters("browser")
	@BeforeClass
	public void invokeBrowser(String browser) {

		driver = ReusableFunctions.invokeBrowser();
		
//		driver = DriverSetup.browserSetup(browser);
		rf = new ReusableFunctions(driver);
		ReusableFunctions.openWebsite("url");

		signup = new Signup(driver, rf);

	}

	@DataProvider(name = "valid")
	public String[][] getValidData() throws Exception {
		String path = System.getProperty("user.dir") + "/src/test/resources/singupdetails.xlsx";
		String sheetName = "valid";
//		Reading data from excel
		return ExcelHandling2.getExcelData(path, sheetName);
	}

	@DataProvider(name = "invalid")
	public String[][] getInvalidData() throws Exception {
		String path = System.getProperty("user.dir") + "/src/test/resources/singupdetails.xlsx";
		String sheetName = "invalid";
//		Reading data from excel
		return ExcelHandling2.getExcelData(path, sheetName);
	}

	@Test(priority = 0, dataProvider = "invalid")
	public void testinvalidSignup(String uname, String pwd) throws InterruptedException {
		assertEquals(signup.invalidSignup(uname, pwd), "Sign up");
		assertEquals(driver.getCurrentUrl(), rf.getval("url"));

	}

	@Test(priority = 1, dataProvider = "valid")
	public void testvalidSignup(String uname, String pwd) throws InterruptedException {

		assertFalse(signup.validSignup(uname, pwd));
		assertEquals(driver.getCurrentUrl(), rf.getval("url"));

	}

	@AfterMethod
	private void takeScreenshot(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			screenShotCounter++;
			try {
				FileUtils.copyFile(screenshot,
						new File(System.getProperty("user.dir") + "/screenshot/" + screenShotCounter + ".jpg"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
}
