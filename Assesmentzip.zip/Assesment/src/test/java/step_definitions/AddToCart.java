package step_definitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertThrows;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.util.Assert;

import base.ReusableFunctions;
import demoblazePom.AddToCartPom;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddToCart {
	WebDriver driver;
	ReusableFunctions rf;
	AddToCartPom pom;

	@Given("user already on demoblaze website")
	public void user_already_on_demoblaze_website() {
		driver = Hooks.driver;
		rf = new ReusableFunctions(driver);

		pom = new AddToCartPom(driver, rf);

	}

	@When("user click on item")
	public void user_click_on_item() {
		pom.clickItem();
		
	}

	@Then("product details is shown")
	public void product_details_is_shown() {
		assertEquals(driver.getCurrentUrl(), rf.getval("itemurl"));
		assertTrue(pom.isProductDescriptionDisplayed(), "product desc not displayed");
		assertTrue(pom.isAddToCartShown(), "Add to cart button not shown");

	}

	@When("user click on add to cart button")
	public void user_click_on_add_to_cart_button() throws InterruptedException {
		pom.addItemToCart();
	}

	@Then("product is added to cart")
	public void product_is_added_to_cart() {
		assertEquals(pom.getItemName(), "Samsung galaxy s6");
	}

}
