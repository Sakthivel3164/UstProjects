package base;

import java.io.FileInputStream;
import java.util.Properties;

public class FileIO {
private static Properties properties;
	
	public static Properties getProperties(){
//		if(properties==null){
			properties = new Properties();
			try {
				FileInputStream fis = new FileInputStream("C:\\Users\\268845\\Documents\\UnitTesting\\trivago_capstone\\src\\main\\java\\base\\config.properties");
				properties.load(fis);
			} catch (Exception e) {
				e.printStackTrace();
			}
//		}
		return properties;
	}

}
