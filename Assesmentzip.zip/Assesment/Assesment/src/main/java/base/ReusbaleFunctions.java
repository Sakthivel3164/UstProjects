package base;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReusbaleFunctions {
	private static WebDriver driver;
	private WebDriverWait wait;
	public static Properties properties;
	public static String browser_choice;

	public ReusbaleFunctions(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		properties = FileIO.getProperties();
	}

//	public ReusableFunctions() {
//		// TODO Auto-generated constructor stub
//	}

	public static WebDriver invokeBrowser() {
		if (properties == null)
			properties = FileIO.getProperties();
		browser_choice = properties.getProperty("browser");
//		

		return DriverSetup.browserSetup(browser_choice);
	}

	/********** open website *********/
	public void openWebsite(String url) {

		driver.get(properties.getProperty(url));

	}

	/********** wait for the element to display on the page *********/
	public void waitForElementToDisplay(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	/********** set text to any input field *********/
	public void setTextToInputField(WebElement element, String text) {
		waitForElementToDisplay(element);
		element.clear();
		element.sendKeys(text);
	}

	/********** click on any element *********/
	public void clickOnElement(WebElement element) {
		waitForElementToDisplay(element);
		element.click();
	}

	public String getval(String s) {
		return properties.getProperty(s);
	}

	public String returnText(WebElement element) {
		return element.getText();
	}

	public void clickTwoButton(WebElement element, WebElement element2) {
		waitForElementToDisplay(element);
		element.click();
		waitForElementToDisplay(element2);
		element2.click();
	}

	public void scrollToElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}


}
