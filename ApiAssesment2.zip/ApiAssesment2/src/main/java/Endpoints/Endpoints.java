package Endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.Posts;

public class Endpoints {
	public static Response createPost(Posts payload)
	{
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.header("Content_Type","application/json","Accept",ContentType.JSON)
				.baseUri(Routes.Base_Uri)
				.basePath(Routes.Post_Base_Path)
				.body(payload)
				.when()
				.post();
		return response;
	}
	
	public static Response getAllPosts()
	{
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.header("Content_Type","application/json","Accept",ContentType.JSON)
				.baseUri(Routes.Base_Uri)
				.basePath(Routes.Get_Base_Path)
				.when()
				.get();
		return response;
	}
	
	public static Response getPostsById(int id)
	{
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.header("Content_Type","application/json","Accept",ContentType.JSON)
				.baseUri(Routes.Base_Uri)
				.basePath(Routes.Get_Base_Path_Id)
				.pathParam("id", id)
				.when()
				.get();
		return response;
	}
	
	public static Response updatePosts(int id,Posts payload)
	{
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.header("Content_Type","application/json","Accept",ContentType.JSON)
				.baseUri(Routes.Base_Uri)
				.basePath(Routes.Get_Base_Path_Id)
				.body(payload)
				.pathParam("id", id)
				.when()
				.put();
		return response;
	}
	
	public static Response partialUpdatePosts(int id,Posts payload)
	{
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.header("Content_Type","application/json","Accept",ContentType.JSON)
				.baseUri(Routes.Base_Uri)
				.basePath(Routes.Get_Base_Path_Id)
				.body(payload)
				.pathParam("id", id)
				.when()
				.patch();
		return response;
	}
	public static Response deletePosts(int id)
	{
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given()
				.header("Content_Type","application/json","Accept",ContentType.JSON)
				.baseUri(Routes.Base_Uri)
				.basePath(Routes.Get_Base_Path_Id)
				.pathParam("id", id)
				.when()
				.delete();
		return response;
	}
	
	
	
	

}
