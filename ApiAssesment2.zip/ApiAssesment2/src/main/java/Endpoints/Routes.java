package Endpoints;

public class Routes {

	public static String Base_Uri = "https://freefakeapi.io";
	public static String Get_Base_Path = "/api/posts";
	public static String Get_Base_Path_Id = "/api/posts/{id}";
	public static String Post_Base_Path = "/api/posts";
	public static String Put_Base_Path = "/api/posts/{id}";
	public static String Patch_Base_Path = "/api/posts/{id}";
	public static String Delete_Base_Path = "/api/posts/{id}";

}
