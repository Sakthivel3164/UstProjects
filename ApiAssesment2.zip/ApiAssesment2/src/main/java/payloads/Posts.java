package payloads;

public class Posts {
	public String title;
	public String content;
	public String slug;
	public String picture;
	public int user;
	public Posts(String title, String content, String slug, String picture, int user) {
		super();
		this.title = title;
		this.content = content;
		this.slug = slug;
		this.picture = picture;
		this.user = user;
	}
	public Posts()
	{
		
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getSlug() {
		return slug;
	}
	public void setSlug(String slug) {
		this.slug = slug;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public int getUser() {
		return user;
	}
	public void setUser(int user) {
		this.user = user;
	}
	
	

}
