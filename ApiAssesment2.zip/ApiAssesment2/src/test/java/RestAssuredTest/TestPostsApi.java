package RestAssuredTest;

import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Endpoints.Endpoints;
import Endpoints.ExcelHandling;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import payloads.Posts;
import utilities.ExtentReportManager;

@Listeners(ExtentReportManager.class)
public class TestPostsApi {

	Posts posts;

	@Test(priority = 0)
	public void testGetAllPosts() {
		Response response = Endpoints.getAllPosts();
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

	@Test(priority = 1)
	public void testGetPostsById() {
		Response response = Endpoints.getPostsById(1);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

	@DataProvider(name = "data")
	public String[][] getData() throws Exception {
		String path = "C:\\Users\\268845\\Documents\\UnitTesting\\ApiAssesment2\\src\\test\\resources\\data.xlsx";
		String sheetName = "Sheet1";
		return ExcelHandling.getExcelData(path, sheetName);
	}

	@Test(priority = 2,dataProvider = "data")
	public void testCreatePost(String title, String content, String slug, String picture, String id) {

		posts = new Posts(title, content, slug, picture, Integer.parseInt(id));
		Response response = Endpoints.createPost(posts);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 201);
	}

	@Test(priority = 3)
	public void testUpdatePosts() {
		posts = new Posts();
		posts.setContent("Content");
		posts.setPicture("picture");
		posts.setSlug("slug");
		posts.setTitle("title");
		posts.setUser(5);
		Response response = Endpoints.updatePosts(2, posts);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

	@Test(priority = 4)
	public void testUpdateSomePosts() {
		posts = new Posts();
		posts.setContent("Content2");
		posts.setTitle("title2");
		posts.setUser(4);
		Response response = Endpoints.partialUpdatePosts(2, posts);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 204);
	}

	@Test(priority = 5)
	public void testDeletePosts() {

		Response response = Endpoints.deletePosts(2);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

	@Test(priority = 6)
	public void schemaValidation() {
		// Load JSON schema file
		File f = new File(System.getProperty("user.dir") + "/src/test/resources/payload/schema.json");
		// Validate schema for first 5 authors
		for (int i = 1; i <= 5; i++) {
			Response response = Endpoints.getPostsById(i);
			response.then().log().all().assertThat().body(JsonSchemaValidator.matchesJsonSchema(f));
			System.out.println("--------------- " + i + " schema ------------");
		}
	}

}
