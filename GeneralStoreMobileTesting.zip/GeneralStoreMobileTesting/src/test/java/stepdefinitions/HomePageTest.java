package stepdefinitions;

import base.ReusableFunction;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.HomePage;

public class HomePageTest {

	public AndroidDriver driver = Hooks.driver;
	ReusableFunction rf;
	HomePage homePage;

	@Given("user is in home page")
	public void user_is_in_home_page() {
		rf = new ReusableFunction();
		homePage = new HomePage(driver);

	}

	@When("user clicks on country")
	public void user_clicks_on_country() {
		homePage.clickCountry();
	}

	@When("user selects a country")
	public void user_selects_a_country() {
		homePage.clickName();
	}

	@When("user sets name")
	public void user_sets_name() {
		homePage.setName();
	}

	@Then("detials entered succesfully")
	public void detials_entered_succesfully() {
		System.out.println("success");
	}

}
