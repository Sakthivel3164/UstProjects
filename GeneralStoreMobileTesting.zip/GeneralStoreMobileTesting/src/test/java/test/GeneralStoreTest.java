package test;

import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.DriverSetup;
import base.ExtentReportManager;
import base.ReusableFunction;
import pom.HomePage;

@Listeners(ExtentReportManager.class)
public class GeneralStoreTest extends DriverSetup {

	HomePage homePage;

	@BeforeClass
	public void initialize() {

		
		homePage = new HomePage(driver);
	}
	
	@DataProvider(name="json")
	public Object[] getData(){
		String file = System.getProperty("user.dir")+"\\src\\main\\resources\\data.json";
		return ReusableFunction.getJsonData(file).toArray();
	}

	@Test(dataProvider = "json")
	public void test(HashMap<String, String> map) {
		homePage.setName(map);
	}

}
