package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = {"classpath:features//Sort.feature"},glue = {"classpath:stepdefinitions"},plugin = { "pretty",
		"html:cucmberReport/report.html" })
public class TestRunner extends AbstractTestNGCucumberTests {

}
