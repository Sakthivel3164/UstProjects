package pom;

import java.util.HashMap;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class HomePage {

	AndroidDriver driver;
	ReusableFunction rf;

	public HomePage(AndroidDriver driver) {
		this.driver = driver;
		rf = new ReusableFunction(driver);
		PageFactory.initElements(new AppiumFieldDecorator(this.driver), this);
	}

	@AndroidFindBy(id = "com.androidsample.generalstore:id/spinnerCountry")
	WebElement country;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Bangladesh']")
	WebElement name;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='3']")
	WebElement search;

	public void clickCountry() {
		rf.clickOnElement(country);

	}

	public void clickName() {
		rf.scrollToText("Bangladesh");
		rf.clickOnElement(name);
	}

	public void setName(HashMap<String, String> map) {
		rf.setTextToInputField(search, map.get("Search_text"));
	}

}
