package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class FileIO {
	public static Properties properties;

	public static Properties getProperties(String fileName) {
		properties = new Properties();
		try {
			FileInputStream stream = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/" + fileName + ".properties");
			properties.load(stream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties;
	}

}
