package com.OverridingBank;

public class BankAccount {
	private String accountNumber;
	private String accountHolder;
	private double balance;
	
	public BankAccount(String accountNumber, String accountHolder, double balance) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolder = accountHolder;
		this.balance = balance;
	}
//	Getters and setters

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
//	Methods
	
	public void deposit(double amount)
	{
		balance+=amount;
		System.out.println("Amount Deposited Succesfully");
	}
	public void withDrawal(double amount)
	{
		if(amount<=balance)
		{
			balance -=amount;
		}
		else if(amount==0)
			System.out.println("Enter Valid Amount");
		else
			System.out.println("Insufficient Balance");
	}
	
	public void displayAccountDetails()
	{
		System.out.println("Account Number: "+accountNumber);
		System.out.println("Account Holder: "+accountHolder);
		System.out.println("Available Balance: "+balance);
	}
	
	
	

}
