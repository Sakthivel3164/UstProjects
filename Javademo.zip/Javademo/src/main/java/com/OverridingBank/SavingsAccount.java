package com.OverridingBank;

public class SavingsAccount  extends BankAccount{
	double interestRate;

	public SavingsAccount(String accountNumber, String accountHolder, double balance, double interestRate) {
		super(accountNumber, accountHolder, balance);
		this.interestRate = interestRate;
	}
	@Override
	public void displayAccountDetails()
	{

		System.out.println("Account Number: "+getAccountNumber());
		System.out.println("Account Holder: "+getAccountHolder());
		System.out.println("Available Balance: "+getBalance());
		System.out.println("Interest Rate: "+interestRate);

	}
	public void applyInterest()
	{
		setBalance(getBalance()+((getBalance()*interestRate*1))/100);
	}

}
