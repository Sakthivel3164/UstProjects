package com.OverridingBank;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int flag = -1;
		BankAccount account;
		System.out.println("Select Account");
		System.out.println();
		System.out.println("1. Savings Account\n2. Checking Account\n");
		int choice = s.nextInt();

		if (choice == 1) {
			System.out.println("Enter Account Number");
			String acc_num = s.next();
			System.out.println("Enter Account Holder Name");
			String name = s.next();
			int balance = 0;
			double interest = 7.5;

			account = new SavingsAccount(acc_num, name, balance, interest);
		} else {
			System.out.println("Enter Account Number");
			String acc_num = s.next();
			System.out.println("Enter Account Holder Name");
			String name = s.next();
			int balance = 0;
			double overDraftLimit = -10000;

			account = new CheckingAccount(acc_num, name, balance, overDraftLimit);
		}

		while (flag == -1) {
			System.out.println("----------------Transaction Menu----------------");
			System.out.println();
			System.out.println("1. Deposit\n2. Withdrawal\n3. Apply Interest\n4. Display Account Details\n5. Exit");
			int choice2 = s.nextInt();
			switch (choice2) {
			case 1: {
				System.out.println("Enter the amount to deposit");
				double deposit = s.nextDouble();
				account.deposit(deposit);
				break;
			}
			case 2: {
				System.out.println("Enter the Amount to Withdraw");
				double withdraw = s.nextDouble();
				account.withDrawal(withdraw);
				break;
			}
			case 3: {
				if (account instanceof CheckingAccount) {
					System.out.println("Cant do this Operation");
				} else {
					SavingsAccount account1 = (SavingsAccount) account;

					account1.applyInterest();
				}

			}
			case 4: {
				System.out.println("----------------Account Details--------------------");
				account.displayAccountDetails();
				break;
			}
			case 5: {
				flag = 1;
				break;
			}
			default:
				System.out.println("Invalid Option");
				break;

			}
		}
	}
}
