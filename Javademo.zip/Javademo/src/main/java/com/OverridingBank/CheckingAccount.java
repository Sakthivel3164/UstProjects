package com.OverridingBank;

public class CheckingAccount extends BankAccount {
	double overdraftLimit;

	public CheckingAccount(String accountNumber, String accountHolder, double balance, double overdraftLimit) {
		super(accountNumber, accountHolder, balance);
		this.overdraftLimit = overdraftLimit;
	}
	@Override
	public void withDrawal(double amount)
	{
		if(amount<=overdraftLimit)
		{
			setBalance(getBalance()-amount);
		}
	}
	@Override
	public void displayAccountDetails()
	{
		System.out.println("Account Number: "+getAccountNumber());
		System.out.println("Account Holder: "+getAccountHolder());
		System.out.println("Available Balance: "+getBalance());
		System.out.println("OverDraft Limit: "+overdraftLimit);
	}
	
	

}
