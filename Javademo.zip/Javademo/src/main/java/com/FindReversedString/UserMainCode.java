package com.FindReversedString;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class UserMainCode {
	public static int getElementMethod(ArrayList<String> list1,String s)
	{
		Collections.sort(list1);
		Collections.reverse(list1);
		for(String s1:list1)
		{
			if(s1.equals(s))
				return list1.indexOf(s1);
		}
		return -1;
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter String");
		String s1 = s.next();
		System.out.println("Enter size");
		int size = s.nextInt();
//		String [] arr = new String[size];
		ArrayList< String> arrayList = new ArrayList<String>();
		for(int i=0;i<size;i++)
		{
			String input = s.next();
			arrayList.add(input);
		}
		System.out.println(getElementMethod(arrayList, s1));
		
	}

}
