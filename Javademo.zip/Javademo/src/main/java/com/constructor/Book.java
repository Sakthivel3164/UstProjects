package com.constructor;

public class Book {
	private String title;
	private String author;
	private String isbn;
	public Book(String title, String author, String isbn) {
		this.title = title;
		this.author = author;
		this.isbn = isbn;
	}
	void displayBooks(Book b)
	{
		System.out.println("--------------Book Details---------------");
		System.out.println("Title: "+b.title);
		System.out.println("Author: "+b.author);
		System.out.println("ISBN: "+b.isbn);
	}
	
	

}
