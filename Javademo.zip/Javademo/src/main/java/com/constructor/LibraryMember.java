package com.constructor;

public class LibraryMember {
	private String name;
	private String memberId;
	private int booksCheckedOut;
//	private Book book;

	int count = 0;

	public LibraryMember(String name, String memberId, int booksCheckedOut) {
		this.name = name;
		this.memberId = memberId;
		this.booksCheckedOut = booksCheckedOut;
	}

	int booksCheckedOut(String s) {
		if (s != null && s == memberId) {
			count++;
			return count;
		} else if (memberId != s)
			return -1;
		
		else
			return 0;

	}

	void displayMemberInfo(LibraryMember l, int checkout) {
		System.out.println();System.out.println("-----------------Member Info---------------");
		System.out.println("Member Name: " + l.name);
		System.out.println("Member ID: " + l.memberId);
		System.out.println();

		System.out.println("Checking out a book for " + l.name + "....");
		if (checkout == -1)
		{
			System.out.println();
			System.out.println("Memeber id Mismatch; Cannot checkout the book");
		}
			
		else if (checkout == 0)
		{
			System.out.println();
			System.out.println("Member id is empty");
			
		}
		else {
			System.out.println();
			System.out.println("Books checked out " + l.count);
		}
			

			

	}

}
