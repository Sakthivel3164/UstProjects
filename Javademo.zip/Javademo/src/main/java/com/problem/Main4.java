package com.problem;
import java.util.Scanner;

public class Main4 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String input = scanner.next();
		String result = UserMainCode4.interchange(input);
		System.out.println(result);
		
		
	}

}
