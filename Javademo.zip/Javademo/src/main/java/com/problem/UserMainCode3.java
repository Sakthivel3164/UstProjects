package com.problem;

public class UserMainCode3 {
	public static String formNewWord(String s,int n)
	{
		String first = s.substring(0,n);
		String second = s.substring(s.length()-n);
		String result = first+second;
		return result;
	}

}
