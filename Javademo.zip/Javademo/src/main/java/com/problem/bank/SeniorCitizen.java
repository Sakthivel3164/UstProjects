package com.problem.bank;

public class SeniorCitizen extends BankAccount {
	
	public SeniorCitizen(double withdrawAmount,double depositAmount) {
		super(withdrawAmount,depositAmount);
	}
	void applyFixedDeposit()
	{
		super.interestRate = 10.5;
		System.out.println("Senior Citizen Interest Rate: "+interestRate);
	}
	

}
