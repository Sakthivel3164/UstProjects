package com.problem.bank;

import java.util.Scanner;

public class InheritenceDemo {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Choose Account Type");
		System.out.println("1. NRI Account/n2. Senior citizen Account/n");
		int choice = s.nextInt();

		System.out.println("Enter Deposit Amount");
		double deposit = s.nextDouble();
		System.out.println("Enter Withdrawal Amount");
		double withdrawal = s.nextDouble();

		if (choice == 1) {
			NRIAccount account = new NRIAccount(withdrawal, deposit);

			account.depositMoney();
			account.withdrawMoney(withdrawal);
			account.applyFixedDeposit();
		} else {
			SeniorCitizen citizen = new SeniorCitizen(withdrawal, deposit);

			System.out.println("-----------------------------------------");
			citizen.depositMoney();
			citizen.withdrawMoney(withdrawal);
			citizen.applyFixedDeposit();
		}

	}

}
