package com.problem;

public class UserMainCode {
	
	public static  int sumOfSquaresOfSquaresOfEvenDigits(int n)
	{
		int temp = n;
		int sum = 0;
		while(temp!=0)
		{
			int rem = temp%10;
			if(rem%2==0)
			{
				sum = sum+(rem*rem);
			}
			temp/=10;
		}
		return sum;
	}

}
