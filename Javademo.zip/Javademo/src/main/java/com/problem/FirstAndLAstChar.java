package com.problem;
import java.util.Scanner;
import java.util.StringTokenizer;

public class FirstAndLAstChar {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String s = scanner.nextLine();
		int result = CheckChar(s);
		System.out.println(result);
		
	}

	private static int CheckChar(String s) {
		StringTokenizer tokenizer = new StringTokenizer(s);
		String s1 = tokenizer.nextToken();
		String s2 = "";
		while(tokenizer.hasMoreTokens())
		{
			s2 = tokenizer.nextToken();
		}
		if(s1.charAt(0)==s2.charAt(s2.length()-1))
			return 1;
		else
			return -1;
		
			
	}

}
