package com.problem;
import java.util.Scanner;
import java.util.StringTokenizer;
public class Main5 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String s = scanner.nextLine();
		StringTokenizer stringTokenizer = new StringTokenizer(s);
		int num = stringTokenizer.countTokens();
		System.out.println(num);
	
		
//		StringTokenizer stringTokenizer = new StringTokenizer(s," ");
////		String s2 = stringTokenizer.nextToken();
////		String s3 = stringTokenizer.nextToken();
////		int count  =stringTokenizer.countTokens();
////		System.out.println(count);
////		System.out.println(s2);
////		System.out.println(s3);
		
		
		
//		
		
	}
	public static String nameFormatter(String s1)
	{
		StringBuffer sb = new StringBuffer();
		StringTokenizer st = new StringTokenizer(s1," ");
		String s2 = st.nextToken();
		String s3 = st.nextToken();
		sb.append(s3).append(",");
		sb.append(s2.substring(0, 1).toUpperCase());
		return sb.toString();
		
		
	}

}