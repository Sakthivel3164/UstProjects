package com.problem;
import java.util.Scanner;

public class Main3 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter String and integer");
		String s = scanner.next();
		int n = scanner.nextInt();
		String result = UserMainCode3.formNewWord(s,n);
		System.out.println(result);
	}

}
