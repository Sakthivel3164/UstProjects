package com.problem.constructor;
import java.util.Scanner;

public class UserInteraction {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Book Title");
		String title = s.nextLine();
		System.out.println("Enter Author Name");
		String author = s.nextLine();
		System.out.println("Enter ISBN");
		String isbn = s.nextLine();
		System.out.println("Enter Member Name");
		String member = s.nextLine();
		System.out.println("Enter Member Id");
		String mid = s.nextLine();
		System.out.println("Select Member for Checkout");
		String cout = s.nextLine();

		Book book = new Book(title, author, isbn);
		LibraryMember libraryMember = new LibraryMember(member, mid,0);
		int checkout_count = libraryMember.booksCheckedOut(cout);
		book.displayBooks(book);
		libraryMember.displayMemberInfo(libraryMember,checkout_count);
		
		
		
	}

}

