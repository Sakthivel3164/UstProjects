package com.problem;

public class UserMainCode2 {
	public static int CheckSum(int n)
	{
		int sum = 0;
		while(n!=0)
		{
			int a = n%10;
			if(a%2==1)
			{
				sum+=a;
			}
			n/=10;
		}
//		System.out.println(sum);
		if(sum%2==0)
			return -1;
		else
			return 1;
		
	}

}
