package com.problem;

public class UserMainCode4 {

	public static String interchange(String input) {
		String output = "";
		char ch[] = new char[input.length()];
		if(input.length()%2==0)
		{
			for(int i=1;i<ch.length;i++)
			{
				ch[i] = (char) (input.charAt(i)+input.charAt(i-1));
			}
		}
		return output;
	}

}
