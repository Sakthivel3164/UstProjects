package com.problem;
import java.util.Scanner;

public class Main2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		int result = UserMainCode2.CheckSum(num);
		System.out.println(result);
		
	}

}
