package com.problem;
import java.util.Scanner;

public class Main1 {
	public static void main(String[] args) {
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter the String with even length");
		String s = scanner.next();
		String result = UserMainCode1.getMiddleCharspresent(s);
		System.out.println(result);
		
	}

}
