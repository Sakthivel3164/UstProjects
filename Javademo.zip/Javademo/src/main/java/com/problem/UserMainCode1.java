package com.problem;

public class UserMainCode1 {

	public static String getMiddleCharspresent(String s) {
		int half = s.length()/2;
		String sub = s.substring(half-1,half+1);
		
		
		return sub;
	}

}
