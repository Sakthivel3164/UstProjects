package com.interface1;

public class Car extends MotorisedVehicle implements IVehicle {

	@Override
	public void drive() {
		System.out.println("Car is moving");

	}

	@Override
	public void turnLeft() {
		System.out.println("Car turn sleft");
	}

	@Override
	public void brake() {
		System.out.println("THe car is in  brake mode");
	}
	
}
