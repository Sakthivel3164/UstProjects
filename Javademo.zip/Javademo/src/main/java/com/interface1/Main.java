package com.interface1;

public class Main {
	public static void main(String[] args) {
		Car car = new Car();
		Train train = new Train();
		car.brake();
		car.checkMotor();
		car.drive();
		car.turnLeft();
		train.brake();
		train.drive();
		train.turnLeft();
		train.getNumberOfPeople();
		
	}

}
