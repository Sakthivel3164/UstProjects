package com.interface1;

public interface IVehicle {
	void drive();
	void turnLeft();
	void brake();

}
