package com.interface1;

public interface IPublicTransport {
	void getNumberOfPeople();

}
