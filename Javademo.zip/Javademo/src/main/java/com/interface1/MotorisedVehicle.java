package com.interface1;

public class MotorisedVehicle {
	public void checkMotor()
	{
		System.out.println("The motor of the vehicle is in good condition");
	}

}
