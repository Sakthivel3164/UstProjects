package com.interface1;

public class Train implements IVehicle, IPublicTransport {

	@Override
	public void getNumberOfPeople() {
		System.out.println("There are 200 people");
	}

	@Override
	public void drive() {
		System.out.println("Train is moving");
	}

	@Override
	public void turnLeft() {
		System.out.println("Train turns left");
	}

	@Override
	public void brake() {
		System.out.println("Train applies brake");
	}

}
