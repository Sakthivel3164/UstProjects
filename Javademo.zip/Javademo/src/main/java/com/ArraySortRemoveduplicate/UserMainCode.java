package com.ArraySortRemoveduplicate;

import java.util.ArrayList;
import java.util.Collections;

public class UserMainCode {
	public static ArrayList<String> orderElements(ArrayList<String> list)
	{
		ArrayList<String> list2 = new ArrayList<String>();
		for(String s:list)
		{
			if(!list2.contains(s))
				list2.add(s);
			
		}
		Collections.sort(list2);
		return list2;
	}

}
