package com.ArraySortRemoveduplicate;
import java.util.Scanner;

import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		ArrayList< String> list = new ArrayList<String>();
		System.out.println("Entre the size of array list");
		int n = s.nextInt();
		System.out.println("Enter the elements");
		for(int i=0;i<n;i++)
		{
			list.add(s.next());
		}
		
		ArrayList<String> result = UserMainCode.orderElements(list);
		System.out.println(result);
		
	}

}
