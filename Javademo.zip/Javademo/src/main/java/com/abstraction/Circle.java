package com.abstraction;

public class Circle extends Shape {
	double radius = 5.0;
	
	@Override
	public double calculateArea()
	{
		double area = 3.14*radius*radius;
		return area;
	}

}
