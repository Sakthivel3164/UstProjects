package com.abstraction;

public class AbstractDemo {
	public static void main(String[] args) {
		Circle circle = new Circle();
		Square square = new Square();
		circle.setColor("green");
		double circle_a = circle.calculateArea();
		square.setColor("Red");
		double sq_a = square.calculateArea();
		System.out.println("Circle Area: "+circle_a);
		System.out.println("Square Area: "+sq_a);
	}

}
