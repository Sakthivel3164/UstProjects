package com.abstraction;

public class Square extends Shape {
	double length = 4.0;
	double breadth = 4.0;
	double area;
	@Override
	public double calculateArea()
	{
		area = length*breadth;
		return area;
	}
	

}
