package com.bank;

public class NRIAccount extends BankAccount {
	
	public NRIAccount(double withdrawAmount,double depositAmount)
	{
		super(withdrawAmount,depositAmount);
	}
	void applyFixedDeposit()
	{
		super.interestRate = 6.5;
		System.out.println("NRI Interest Rate: "+interestRate);
	}
	

}
