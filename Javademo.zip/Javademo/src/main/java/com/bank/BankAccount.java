package com.bank;

public class BankAccount {
	double withdrawAmount;
	double depositAmount;
	double interestRate = 9.5;
	double balance;

	public  BankAccount(double withdrawAmount, double depositAmount) {
		this.withdrawAmount = withdrawAmount;
		this.depositAmount = depositAmount;
		this.balance = depositAmount;
	}

	void depositMoney() {
		System.out.println("Deposit Amount: " + depositAmount);
	}

	void withdrawMoney(double withdrawalAmount) {
		if (withdrawalAmount <= balance) {
			balance -= withdrawAmount;
			System.out.println("Withdrawal Succesfull");
			System.out.println("Amount Withdrwan: "+withdrawalAmount);
			System.out.println("Available Balance: " + balance);
		} else
			System.out.println("Insufficient Balance");

	}

}
