package com.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class SortCitiesReverse implements Comparator<String>  {
	public static void main(String[] args) {
		ArrayList< String> list = new ArrayList<String>();
		list.add("Kochi");
		list.add("tvm");
		list.add("kollam");
		list.add("palakkad");
		list.add("malapuram");
		
		Collections.sort(list, new SortCitiesReverse());
	System.out.println(list);
	
	
	}

	@Override
	public int compare(String o1, String o2) {
		
		return -1*o1.compareTo(o2);
	}

	
	}
	
	


