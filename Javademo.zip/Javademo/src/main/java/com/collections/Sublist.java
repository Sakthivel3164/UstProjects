package com.collections;

import java.util.ArrayList;

public class Sublist {
	public static void main(String[] args) {
		ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("Kochi");
		arrayList.add("tvm");
		arrayList.add("palakkad");
		arrayList.add("alappuzha");
		arrayList.add("new york");
		arrayList.add("idukki");
		Object[] arr = new String[10];
		arr = arrayList.toArray();
		for(Object s:arr)
		{
			System.out.println(s);
		}
		
	}

}
