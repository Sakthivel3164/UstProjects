package com.collections;

import java.util.ArrayList;
import java.util.Collections;

public class SmallestAndLargestName {
	public static void main(String[] args) {
		ArrayList<String> arrayList = new ArrayList<String>();
		ArrayList<String> result = new ArrayList<String>();
		int max_length = Integer.MIN_VALUE;
		int min_length = Integer.MAX_VALUE;
		String min = null;
		String max = null;
		arrayList.add("Kochi");
		arrayList.add("tvm");
		arrayList.add("palakkad");
		arrayList.add("alappuzha");
		arrayList.add("new york");
		arrayList.add("idukki");
		for(String s:arrayList)
		{
			if(s.length()>max_length)
			{
				max_length = s.length();
				max = s;
				
			}
				
			else if(s.length()<min_length)
			{
				min_length = s.length();
				min = s;
			}
				
		}
		result.add(max);
		result.add(min);
		Collections.sort(result);
		System.out.println(result);

	}

}
