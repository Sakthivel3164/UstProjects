package com.collections;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class ListBasics {
	public static void main(String[] args) {
		List< String> list = new ArrayList<String>();
		list.add("Kochi");
		list.add("Ernakulam");
		list.add("Trivandrum");
		list.add("Kozhikode");
		list.add("Kannur");
		for(String s:list)
			System.out.println(s);
		ListIterator iterator = list.listIterator();
		while(iterator.hasNext())
		{
			String s = (String) iterator.next();
			System.out.println(s);
		}
		System.out.println("------------------------------");
		System.out.println();
		
		list.add(2,"Kollam")	;
		for(String s:list)
			System.out.println(s);
		
		System.out.println();
		list.remove(0);
		list.remove("Kozhikode");
		list.add("Trivandrum");
		list.add("Kozhikode");
		list.add("Kannur");
		for(String s:list)
			System.out.println(s);
		
		System.out.println();
		
		for(String s:list)
		{
			if(s=="Kozhikode")
				System.out.println(s);
		}
		list.add(1,"NewYork");
		for(String s:list)
			System.out.println(s);
		System.out.println();
		
		list.set(2, "USa");
		
		for(String s:list)
			System.out.println(s);
		
		System.out.println(list.size());
		
		
		
	}

}
