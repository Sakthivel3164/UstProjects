package ListSortMerge;
import java.util.Scanner;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class UserMainCode {
	public static ArrayList<Integer> sortMergedArrayList(ArrayList<Integer> list1,ArrayList<Integer> list2)
	{
		list1.addAll(list2);
//		Iterator<Integer> iterator = list1.iterator();
		Collections.sort(list1);
		for(int i:list1)
			System.out.println(i);
		ArrayList<Integer> list3 = new ArrayList<Integer>();
		int j = 0;
		for(int i=0;i<list1.size();i++)
		{
			if(i==2||i==6||i==8)
			{
				list3.add(j, list1.get(i));
				j++;
			}
		}
		return list3;
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		ArrayList<Integer> list1 = new ArrayList<Integer>();
		ArrayList<Integer> list2 = new ArrayList<Integer>();
		ArrayList<Integer> newList = new ArrayList<Integer>();
		for(int i=0;i<5;i++)
			list1.add(s.nextInt());
		for(int i=0;i<5;i++)
			list2.add(s.nextInt());
		newList = UserMainCode.sortMergedArrayList(list1, list2);
		
		for(int a:newList)
		{
			System.out.println(a);
		}
	}

}
