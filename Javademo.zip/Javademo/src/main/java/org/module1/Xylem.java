package org.module1;

public class Xylem {
	public static void main(String[] args) {
		int n = 4222242;
		int last = n%10;
		int a = 0;
		int sum = 0;
		n/=10;
		while(n>9)
		{
			a = n%10;
			sum+=a;
			n/=10;
		}
		if(sum==(last+n))
			System.out.println("Xylem");
		else
			System.out.println("Phloem");
	}

}
