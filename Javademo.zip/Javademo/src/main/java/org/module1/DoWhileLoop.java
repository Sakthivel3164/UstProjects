package org.module1;
import java.util.Scanner;

public class DoWhileLoop {
	public static void main(String[] args) {
		int n = 0;
		do {
			System.out.println("Enter a number");
			@SuppressWarnings("resource")
			Scanner s = new Scanner(System.in);
		    n = s.nextInt();
		}
		while(n<1 || n>10);
		
	}

}
