package org.module1;

import java.util.Scanner;

public class BugHunt {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println(calculateSum(arr));
		sc.close();
	}

	public static int calculateSum(int[] arr) {
		int evenSum = 0, oddSum = 0;
		for (int j = 0; j < arr.length; j++) {
			if (arr[j] % 2 == 0)
				evenSum += (arr[j] * arr[j]);
			else
				oddSum += Math.pow(arr[j], 3);
		}
		return evenSum + oddSum;
	}
}
