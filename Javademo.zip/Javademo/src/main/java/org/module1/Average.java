package org.module1;

public class Average {
	
	public int sum1() {
		int a =10;
		int b =15;
		int c =20;
		int d =30;
		int e =50;
		int sum = a+b+c+d+e;
		return sum;
	}
	
	public int average() {
		int a =10;
		int b =15;
		int c =20;
		int d =30;
		int e =50;
		int avg1 = (a+b+c+d+e)/5;
		return avg1;
	}
	public static void main(String[] args) {
		Average avg = new Average();
		
		System.out.println("Sum is :"+ avg.sum1());
		System.out.println("Average is :"+ avg.average());
	}

}
