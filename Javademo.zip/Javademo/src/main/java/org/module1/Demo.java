package org.module1;

public class Demo {
	int a = 10 ;
	int b = 5;
	
	public void  Demo1() {
		int a = 12;
		int b = 13;
		 System.out.println(a);
		 System.out.println(this.a);
	}
	public static void main(String[] args) {
		Demo demo = new Demo();
		int a = 30;
		demo.Demo1();
		System.out.println(a);
	}

}
