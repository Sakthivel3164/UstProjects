package org.module1;

import java.util.Scanner;

public class Marks {
	public static String marks(int percentage) {
		if (percentage < 45)
			return "fail";
		else if (percentage >= 45 && percentage < 70)
			return "3rd class";
		else if (percentage >= 70 && percentage < 85)
			return "2nd class";
		else if (percentage >= 85 && percentage < 100)
			return "1st class";
		else
			return "Distinction";

	}

	public static void main(String[] args) {
		Average av = new Average();
		int percentage = av.average();
		System.out.println(marks(percentage));

	}

}
