package org.module1;

public class Prime {
	public static void main(String[] args) {
		int n = 172;
		int count = 0;
		if(n%2==0)
		{
			System.out.println("Not a Prime");
			return;
		}
			
		for(int i=1;i<=n;i=i+2)
		{
			if(n%i==0)
				count++;
			
		}
		if(count==2)
			System.out.println("Prime");
		else
			System.out.println("Not prime");
	}

}
