package org.module1;

public class OddNumWithoutIf {
	public static void main(String[] args) {
		int n = 1;
		for(int i=1;i<=15;i=i+2)
			System.out.println(i);
	}

}
