package org.module1;
import java.util.Scanner;

public class DynamicInput {
	public static void main(String[] args) {
		
		System.out.println("Enter the marks");
		Scanner scanner = new Scanner(System.in);
		int mark1 = scanner.nextInt();
		int mark2 = scanner.nextInt();
		int mark3 = scanner.nextInt();
		
		int sum  = mark1+mark2+mark3;
		int avg = sum/3;
		
		System.out.println("Sum is: "+sum);
		System.out.println("Average is:"+avg);
	}
	

}
