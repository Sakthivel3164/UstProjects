package org.module1;

import java.util.Scanner;

public class ArrayMaxElement {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.println("Enter the array size");
		int size = s.nextInt();
		int[] arr = new int[size];
		System.out.println("Enter the elemnts");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = s.nextInt();
		}
		int maxNum = findMax(arr);
		System.out.println("Max element is: " + maxNum);

	}

	public static int findMax(int arr[]) {
		int max = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > max) {
				max = arr[i];
			}
		}
		return max;
	}

}
