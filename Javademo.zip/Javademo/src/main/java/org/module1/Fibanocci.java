package org.module1;
import java.util.Scanner;

public class Fibanocci {
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		for(int i=1;i<=n;i++)
		{
			if(n==1)
				System.out.println(0);
			else if(n==2)
				System.out.println(1);
			else
			{
				int n1 = 0;
				int n2 = 1;
				int n3 = n1+n2;
				System.out.println(0);
				System.out.println(1);
				System.out.println();
				
			}
		}
		
		
	}

}
