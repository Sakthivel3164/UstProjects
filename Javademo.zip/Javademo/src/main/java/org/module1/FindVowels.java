package org.module1;

public class FindVowels {
	public static void main(String[] args) {
		String s  = "Sakthivel";
		int[] result = position(s);
		
		for(int a:result)
		{
			if(a!=0)
				System.out.println(a);
		}
	
	}
	public static int[] position(String s)
	{
		int j = 0;
		int count = 0;
		int [] arr = new int[s.length()];
		for(int i=0;i<s.length();i++)
		{
			char c = s.charAt(i);
			Character.toLowerCase(c);
			if(c=='a' || c=='i' || c=='e' || c=='o' || c=='u')
			{
				int ind = s.indexOf(c);
				arr[j] = ind;
				j++;
			}
		}
		return arr;
		
	}

}
