package org.module1;

public class Array {
	public static void main(String[] args) {
		int marks1[][] = {
				{23,34,56},
				{34,45,67},
				{23,87,90}
		};
		int marks2[][] = {
				{13,54,26},
				{54,45,67},
				{23,97,50}
		};
		int marks3[][] = new int[3][3];
				
		
		
//		for(int i=0;i<marks1.length;i++)
//		{
//			for(int j=0;j<marks1.length;j++)
//			{
//				System.out.print(marks1[i][j]+" ");
//			}
//			System.out.println();
//		}
//		System.out.println();
//		
//		for(int i=0;i<marks2.length;i++)
//		{
//			for(int j=0;j<marks2.length;j++)
//			{
//				System.out.print(marks2[i][j]+" ");
//			}
//			System.out.println();
//		}
		
		for(int i=0;i<marks2.length;i++)
		{
			for(int j=0;j<marks2.length;j++)
			{
				marks3[i][j] = marks1[i][j]*marks2[i][j];
			}
		}
		for(int i=0;i<marks3.length;i++)		{
			for(int j=0;j<marks3.length;j++)
			{
				System.out.print(marks3[i][j]+" ");
			}
				System.out.println();
		}
		
		
	}

}
