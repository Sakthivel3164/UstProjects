package debugging;

import java.util.Scanner;

public class StringChar {
	
        public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String s1=s.nextLine();
        String c = s.next();
        String output=removeCharacter(s1,c);
        System.out.println(output);
        }
        public static String removeCharacter(String s1,String c)
        {
        	String d  ;
        	d = s1.replaceFirst(c, "");
        	
        return d;
        }


}
