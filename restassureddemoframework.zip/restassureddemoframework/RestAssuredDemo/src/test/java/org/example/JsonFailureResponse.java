package org.example;

public class JsonFailureResponse {
    String Faultid;
    String Fault;
}
