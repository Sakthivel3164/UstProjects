package org.example;

import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

public class RandomNumbers {
    public static void main(String[] args) {
        Integer[] arr = new Integer[10];
        for (int i = 0; i <arr.length; i++) {
            arr[i] = i;
        }
        Collections.shuffle(Arrays.asList(arr));
        System.out.println(Arrays.toString(arr));

    }
}
