package com.example.endpoints;

public class Routes {

	public static String baseuri="https://fakerestapi.azurewebsites.net/";
	public static String post_basePath="/api/v1/Books";
	public static String get_basePath="/api/v1/Books/{id}";
	public static String delete_basePath="/api/v1/Books/{id}";
	public static String update_basePath="/api/v1/Books/{id}";
}
