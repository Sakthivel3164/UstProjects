package com.example.endpoints;

public class UserModel {

	private long id;
	private String title;
	private String description;
	private String pageCount;
	private String excerpt;
	private String publishDate;

	// Default constructor
	public UserModel() {
	}

	// Parameterized constructor

//	@Override
//	public String toString() {
//		return "User{" + "id=" + id + ", name='" + name + '\'' + ", email='" + email + '\'' + ", gender='" + gender
//				+ '\'' + ", status='" + status + '\'' + '}';
//	}

	public UserModel(long id, String title, String description, String pageCount, String excerpt, String publishDate) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.pageCount = pageCount;
		this.excerpt = excerpt;
		this.publishDate = publishDate;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPageCount() {
		return pageCount;
	}

	public void setPageCount(String pageCount) {
		this.pageCount = pageCount;
	}

	public String getExcerpt() {
		return excerpt;
	}

	public void setExcerpt(String excerpt) {
		this.excerpt = excerpt;
	}

	public String getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}

}
