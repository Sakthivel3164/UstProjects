package com.example.endpoints;

public class Routes {

	public static String baseuri="https://fakerestapi.azurewebsites.net/";
	public static String post_basePath="/api/v1/Books";
	public static String get_basePath="/api/v1/Books/{id}";
	public static String delete_basePath="/api/v1/Books/{id}";
	public static String update_basePath="/api/v1/Books/{id}";
}
//RestAssured.baseURI = "https://petstore.swagger.io/v2/user";
//// Username and Password
//String username = "roshan";
//String password = "shafeek";
//// Sending GET request with username and password in headers
//Response response = given()
//        .header(new Header("username", username))
//        .header(new Header("password", password))
//        .when()
//        .get("/login");



//uri - https://fakerestapi.azurewebsites.net/
//post_basepath - /api/v1/Books
//put_basepath - /api/v1/Books
//get_basepath - /api/v1/Books/{id}
//  6884987
//update_basepath - /api​/v1​/Books​/{id}
//
//public static String baseuri="https://gorest.co.in/";
//public static String post_basePath="/public/v2/users";
//public static String get_basePath="/public/v2/users/{userid}";
//public static String delete_basePath="/public/v2/users/{userid}";
//public static String update_basePath="/public/v2/users/{userid}";