package endpoints;

public class Routes {

	public static String  baseuri="https://petstore.swagger.io";
	public static String  base_get_single_username="/v2/user/{username}";
	public static String  base_get_single_login="/v2/user/login?";
	public static String  base_post="/v2/user";
	public static String  base_put="/v2/user/{username}";
	public static String  base_delete="/v2/user/{username}";
//	public static String baseurii="/api/users/2";
	
	
	
}
