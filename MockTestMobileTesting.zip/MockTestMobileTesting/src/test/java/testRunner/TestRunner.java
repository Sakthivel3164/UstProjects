package testRunner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(tags = "", features = {"C:\\Users\\268845\\Documents\\MobileTesting\\MobileTesting\\MockTestMobileTesting\\src\\test\\resources\\feature\\test.feature"}, glue = {"stepDefintion"},
              plugin = {})
public class TestRunner extends AbstractTestNGCucumberTests{

}
