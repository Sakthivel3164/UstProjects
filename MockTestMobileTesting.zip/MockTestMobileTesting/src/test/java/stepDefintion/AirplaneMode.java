package stepDefintion;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import com.base.ReusableFunctions;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AirplaneMode {
	
	public AndroidDriver driver;
	public ReusableFunctions rf;
	UiAutomator2Options options;

	@Given("user is on settings application")
	public void user_is_on_settings_application() throws MalformedURLException {
		rf = new ReusableFunctions();
		options = new UiAutomator2Options();
		options.setDeviceName(rf.getPropertyValue("deviceName"));
		options.setApp(System.getProperty(rf.getPropertyValue("app")));
		options.setPlatformName(rf.getPropertyValue("platformName"));

		if (rf.getPropertyValue("appType").equals("installed")) {
			options.setApp(System.getProperty(rf.getPropertyValue("app")));
		} else {

			options.setAppPackage(rf.getPropertyValue("appPackage"));
			options.setAppActivity(rf.getPropertyValue("appActivity"));
		}

		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		AirplaneMode airplaneMode = new AirplaneMode();
	}

	@When("user clicks on network and interests")
	public void user_clicks_on_network_and_interests() {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}

	@When("user clicks on airplanemode button")
	public void user_clicks_on_airplanemode_button() {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}

	@Then("aiplane mode is turned on")
	public void aiplane_mode_is_turned_on() {
		// Write code here that turns the phrase above into concrete actions
		throw new io.cucumber.java.PendingException();
	}

}
