import static org.testng.Assert.assertTrue;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.base.DriverSetup;

import pom.RingtonePom;

public class RingtoneTest extends DriverSetup {
	public RingtonePom pom;

	@BeforeClass
	public void initialize() {
		pom = new RingtonePom(driver);

	}

	@org.testng.annotations.Test(priority = 0)
	public void testClickSOundAndVibration() {

		test = reports.createTest("ClickSOundAndVibration").assignAuthor("sakthi").assignCategory("Unit test");
		assertTrue(pom.clickSoundAndVibration());

	}

	@Test(priority = 1)
	public void testClickPhoneRingtone() {

		test = reports.createTest("ClickPhoneRingtone").assignAuthor("sakthi").assignCategory("Unit test");
		assertTrue(pom.clickPhoneRingtone());
	}

	@Test(priority = 2)
	public void testClickRingtone() {

		test = reports.createTest("ClickRingtone").assignAuthor("sakthi").assignCategory("Unit test");
		assertTrue(pom.clickRingtone());
	}

	@Test(priority = 3)
	public void testClickSaveButton() {

		test = reports.createTest("ClickSaveButton").assignAuthor("sakthi").assignCategory("Unit test");
		assertTrue(pom.clickSaveButton());
	}

}
