package com.base;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.testng.annotations.BeforeTest;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class DriverSetup extends ReportSetup {

	public AndroidDriver driver;
	public ReusableFunctions rf;
	UiAutomator2Options options;

	@BeforeTest
	public void setUp() throws MalformedURLException {

//		FileInputStream inputStream = new FileInputStream("\"C:\\\\Users\\\\268845\\\\Desktop\\\\appium.bat\"");
//		inputStream.re
//		File file = new File("C:\\Users\\268845\\Desktop\\appium.bat");
//		Desktop desktop = Desktop.getDesktop();
//		try {
//			desktop.open(file);
//			
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
		reports = ReusableFunctions.report("Ringtone setting.html");
		rf = new ReusableFunctions();
		options = new UiAutomator2Options();
		options.setDeviceName(rf.getPropertyValue("deviceName"));
		options.setApp(System.getProperty(rf.getPropertyValue("app")));
		options.setPlatformName(rf.getPropertyValue("platformName"));

		if (rf.getPropertyValue("appType").equals("installed")) {
			options.setApp(System.getProperty(rf.getPropertyValue("app")));
		} else {

			options.setAppPackage(rf.getPropertyValue("appPackage"));
			options.setAppActivity(rf.getPropertyValue("appActivity"));
		}

		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

	}

}
