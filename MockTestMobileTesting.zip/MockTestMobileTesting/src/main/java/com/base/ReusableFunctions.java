package com.base;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Collections;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;

public class ReusableFunctions {
	private static  AndroidDriver driver;
	private WebDriverWait wait;
	public static Properties properties;
	static ExtentSparkReporter htmlReporter;
	static ExtentReports reports;
	ExtentTest test;

	public ReusableFunctions() {

	}

	public ReusableFunctions(AndroidDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(this.driver, Duration.ofSeconds(20));
		properties = FileIO.getProperties();
	}

//***************get from  property file **************
	public String getPropertyValue(String s) {
		if (properties == null) {
			properties = FileIO.getProperties();
		}
		return properties.getProperty(s);
	}

	public static ExtentReports report(String string) {
		htmlReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "\\report\\" + string);
		reports = new ExtentReports();
		reports.attachReporter(htmlReporter);
		// add environtment variables
		reports.setSystemInfo("OS", "Windows");
		reports.setSystemInfo("Browser", "chrome");
		reports.setSystemInfo("Environment", "QA");
		reports.setSystemInfo("user", "Sakthi | shebin ");

		// configuration look
		String customCss = ".test-name { font-size: 20px; color: #4CAF50; }" + ".category-status { font-weight: bold; }"
				+ ".node-name { background-color: #D3D3D3; padding: 5px; border-radius: 3px; }"
				+ ".card-panel { background: linear-gradient(to bottom, #FFFFFF, #E0E0E0); }"
				+ ".step-details { font-family: Arial, sans-serif; font-size: 14px; }" + ".fa { color: #FF5722; }"
				+ "table { border: 1px solid #DDDDDD; width: 100%; }" + "th, td { padding: 10px; text-align: left; }"
				+ "th { background-color: #333333; color: #FFFFFF; }";

		htmlReporter.config().setCss(customCss);
		htmlReporter.config().setDocumentTitle("Pharmacy Report");
		htmlReporter.config().setReportName("Pharmacy Report");
		htmlReporter.config().setTheme(Theme.DARK);
		htmlReporter.config().setTimeStampFormat("EEE,MMM dd, yyyy, hh:mm a '('zzz')'");
		return reports;

	}

	/************** Take screenshot ****************/
	public static void takeScreenShot(String filepath) {
//		System.out.println("filepath:  " + filepath);
		TakesScreenshot takeScreenShot = (TakesScreenshot) driver;
		File srcFile = takeScreenShot.getScreenshotAs(OutputType.FILE);

		// Generate a timestamp
		String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());

		// Append the timestamp to the filename
		String fileNameWithTimestamp = "screenshot_" + timestamp + ".png";

		// Construct the destination file path with the unique filename
		File destFile = new File(filepath + File.separator + fileNameWithTimestamp);

		try {
			FileUtils.copyFile(srcFile, destFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//	 Method to tap by coordinates
	public void tapByCoordinates(int x, int y) {
		PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		Sequence tap = new Sequence(finger, 1)
				.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(), x, y))
				.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
				.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		driver.perform(Collections.singletonList(tap));
		takeADelay(2);
	}

	public void clickOnElement(WebElement element) {
		waitForElementToDisplay(element);
		element.click();
	}

	public void waitForElementToDisplay(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public void longPressAction(WebElement ele) {
		((JavascriptExecutor) driver).executeScript("mobile: longClickGesture",
				ImmutableMap.of("elementId", ((RemoteWebElement) ele).getId(), "duration", 2000));
	}

	public void scrollToEndAction() {
		boolean canScrollMore;
		do {
			canScrollMore = (Boolean) ((JavascriptExecutor) driver).executeScript("mobile: scrollGesture", ImmutableMap
					.of("left", 100, "top", 100, "width", 200, "height", 200, "direction", "down", "percent", 3.0

					));
		} while (canScrollMore);
	}

	public void scrollToText(String text) {

		driver.findElement(AppiumBy
				.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"" + text + "\"));"));
	}

	public void swipeAction(WebElement ele, String direction) {
		((JavascriptExecutor) driver).executeScript("mobile: swipeGesture",
				ImmutableMap.of("elementId", ((RemoteWebElement) ele).getId(),

						"direction", direction, "percent", 0.75));

	}

	public void clickTwoElement(WebElement element, WebElement element2) {
		waitForElementToDisplay(element);
		element.click();
		waitForElementToDisplay(element2);
		element2.click();
	}

	public void dragAndDrop(WebElement element, int x, int y) {
		((JavascriptExecutor) driver).executeScript("mobile: dragGesture",
				ImmutableMap.of("elementId", ((RemoteWebElement) element).getId(), "endX", x, "endY", y));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void scrollToElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public void scrollByPixel(int x, int y) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + x + ", " + y + ");", "");
	}

	public void takeADelay(int i) {
		try {
			Thread.sleep(i * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void refresh() {
		driver.navigate().refresh();
	}

	public void setTextToInputField(WebElement element, String text) {
		waitForElementToDisplay(element);
		element.sendKeys(text);
	}

	public void setTextToInputFieldandEnter(WebElement element, String text) {
		waitForElementToDisplay(element);
//		element.clear();
		element.sendKeys(text);
		element.sendKeys(Keys.ENTER); // Press "Enter" key after sending text
	}

}
