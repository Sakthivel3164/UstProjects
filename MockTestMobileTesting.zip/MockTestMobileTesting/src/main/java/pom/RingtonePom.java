package pom;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.base.ReusableFunctions;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class RingtonePom {

	AndroidDriver driver;
	ReusableFunctions rf;

	public RingtonePom(AndroidDriver driver) {
		this.driver = driver;
		this.rf = new ReusableFunctions(this.driver);
		PageFactory.initElements(new AppiumFieldDecorator(this.driver), this);
	}

	@AndroidFindBy(className = "android.widget.RelativeLayout")
	List<WebElement> listSettings;

	@AndroidFindBy(className = "android.widget.FrameLayout")
	List<WebElement> soundList;

	@AndroidFindBy(accessibility = "Phone ringtone")
	WebElement ringtoneHeading;

	@AndroidFindBy(accessibility = "Sound & vibration")
	WebElement soundHeading;

	@AndroidFindBy(className = "android.widget.LinearLayout")
	List<WebElement> ringtoneList;

	@AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"My Sounds\"]/android.view.ViewGroup/android.view.View")
	WebElement mySoundsHeading;

	@AndroidFindBy(id = "com.google.android.soundpicker:id/save")
	WebElement saveButton;

	@AndroidFindBy(className = "android.widget.TextView")
	List<WebElement> list;

	public boolean clickSoundAndVibration() {

		rf.clickOnElement(listSettings.get(6));
		return soundHeading.isDisplayed();

	}

	public boolean clickPhoneRingtone() {

		rf.clickOnElement(listSettings.get(1));
		return ringtoneHeading.isDisplayed();

	}

	public boolean clickRingtone() {

		rf.clickOnElement(ringtoneList.get(2));
		return mySoundsHeading.isDisplayed();
	}

	public boolean clickSaveButton() {
		rf.clickOnElement(saveButton);
		return soundHeading.isDisplayed();
	}

}
