package pom;

import org.openqa.selenium.support.PageFactory;

import com.base.ReusableFunctions;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class AirplaneModePom {

	AndroidDriver driver;
	ReusableFunctions rf;

	public AirplaneModePom(AndroidDriver driver) {
		this.driver = driver;
		this.rf = new ReusableFunctions(this.driver);
		PageFactory.initElements(new AppiumFieldDecorator(this.driver), this);
	}
	
}
