package testNg;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import pom.CartPage;
import pom.HomePage;
import pom.ProductList;
import ust.UiAssesment.Base.DriverSetup;
import ust.UiAssesment.Base.ExcelHandling;
import ust.UiAssesment.Base.ExtentReportManager;
import ust.UiAssesment.Base.ReusableFunctions;

@Listeners(ExtentReportManager.class)
public class AddToCartTest {

	public WebDriver driver;
	ReusableFunctions rf;
	HomePage homePage;
	ProductList list;
	CartPage cartPage;

	@Parameters("browser")
	@BeforeClass
	public void initialize(String browser) {
		rf = new ReusableFunctions();
//		driver = rf.invokeBrowser(); // initilazie browser
		driver = DriverSetup.browserSetup(browser);
		driver.get("https://freakins.com/");
//		rf.getPropertyValue("url");
		homePage = new HomePage(driver);
	}

	@DataProvider(name="search")
	public String[][] getData() throws Exception
	{
		String path = "C:\\Users\\268845\\Documents\\UnitTesting\\UiAssesment\\src\\test\\resources\\data.xlsx";
		String sheetName = "Sheet1";
		return ExcelHandling.getExcelData(path, sheetName);
	}
//	validate url of jean search page and page heading
	@Test(priority = 0,dataProvider = "search")
	public void testSearchProduct(String data) {
		list = homePage.searchItem(data);
		assertEquals(driver.getCurrentUrl(), rf.getPropertyValue("jeansurl"));
		assertTrue(list.isJeanPageDisplayed());

	}

	@Test(priority = 1)
	public void testProductNames(String browser) {
		assertTrue(list.checkNames(), "Search results are not accurate");

	}

	@Test(priority = 2)
	public void clickProduct() {
		cartPage = list.clickProduct();
		assertEquals(cartPage.getProductName(), "ice Wash Straight Leg Women'S Jeans");
		assertEquals(driver.getCurrentUrl(), rf.getPropertyValue("womenjeanurl"));

	}

}
