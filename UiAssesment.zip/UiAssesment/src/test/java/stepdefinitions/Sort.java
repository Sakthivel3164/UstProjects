package stepdefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.AccessoriesPage;
import ust.UiAssesment.Base.ReusableFunctions;

public class Sort {

	public WebDriver driver = Hooks.driver;
	AccessoriesPage page;
	ReusableFunctions rf;

	@Given("user is in home page")
	public void user_is_in_home_page() {
		page = new AccessoriesPage(driver);
		rf = new ReusableFunctions();

	}

	@When("user clicks on accessories")
	public void user_clicks_on_accessories() {
		page.clickAccessories();
	}

	@When("user clicks on sort")
	public void user_clicks_on_sort() {
		page.clickSortButton();
	}

	@Then("sorting options is shown")
	public void sorting_options_is_shown() {
		assertTrue(page.isSortByPopOverIsShown());

	}

	@When("user clicks on sort by ascending")
	public void user_clicks_on_sort_by_ascending() {
		page.clickPriceLowToHigh();
	}

	@Then("products are sorted in ascending order of price")
	public void products_are_sorted_in_ascending_order_of_price() {

		assertTrue(page.price());
		assertEquals(driver.getCurrentUrl(), rf.getPropertyValue("urlsort"));
	}

}
