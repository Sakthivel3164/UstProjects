package ust.UiAssesment.Base;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ReusableFunctions {
	static ExtentSparkReporter htmlReporter;
	static ExtentReports reports;
	ExtentTest test;

	private WebDriver driver;
	private WebDriverWait wait;
	public static Properties properties;

	public ReusableFunctions(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));

	}

	public ReusableFunctions() {
		properties = FileIO.getProperties();
	}

	public WebDriver invokeBrowser() {
		if (properties == null)
			properties = FileIO.getProperties();
		String browser_choice = properties.getProperty("browser");

		return DriverSetup.browserSetup(browser_choice);
	}

//**********open website*********/
	public void openWebsite(String url) {
//		if (properties == null) {
//			properties = FileIO.getProperties();
//		} else {
//			driver.get(properties.getProperty(url));
//		}

		driver.get(properties.getProperty(url));
	}

//***************get from  property file **************
	public String getPropertyValue(String s) {
//		if (properties == null) {
//			properties = FileIO.getProperties();
//		}
		return properties.getProperty(s);
	}

	public void waitForElementToDisplay(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public void fluentWait() {
		FluentWait<WebDriver> wait1 = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(20))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class, StaleElementReferenceException.class);
	}

	public void switchToChildWindow() {
		String parent = driver.getWindowHandle();

		Set<String> set = driver.getWindowHandles();
//		System.out.println(set);
		for (String handle : set) {
			if (!handle.equals(parent)) {
				driver.switchTo().window(handle);
				System.out.println("Child window title: " + driver.getTitle());
			}
//			switch back to parent window

		}

	}

	public void switchToParentHandle() {
		String child = driver.getWindowHandle();

		Set<String> set = driver.getWindowHandles();
		for (String handle : set) {
			if (!handle.equals(child)) {
				driver.switchTo().window(handle);
				System.out.println("Parent window title: " + driver.getTitle());
			}
		}
	}

	public void switchToFrame(WebElement element) {
		waitForElementToDisplay(element);
		driver.switchTo().frame(element);
	}

	/******** send search element ***************/
	public void setTextToInputField(WebElement element, String text) {
		waitForElementToDisplay(element);
		element.clear();
		element.sendKeys(text);
	}

	// *********************click elemet***********************
	public void clickOnElement(WebElement element) {
		waitForElementToDisplay(element);
		element.click();
	}

	// ********************* Get Text ***********************
	public String ReturnGetText(WebElement element) {
		waitForElementToDisplay(element);
		return element.getText();

	}

	// ********************** Action *******************

	public void HoldTheElement(WebElement element, WebElement newoption) {
		waitForElementToDisplay(element);
		element.click();
		waitForElementToDisplay(newoption);
		newoption.click();

	}

	public void clearInput(WebElement element) {
		waitForElementToDisplay(element);
		element.clear();
	}

	public boolean isDisplayed(WebElement element) {
		waitForElementToDisplay(element);
		return element.isDisplayed();
	}

	public boolean isEnabled(WebElement element) {
		waitForElementToDisplay(element);
		return element.isEnabled();
	}

	/************** Take screenshot ****************/
	public String takeScreenShot(String filepath) {
		System.out.println("filepath:  " + filepath);
		TakesScreenshot takeScreenShot = (TakesScreenshot) driver;
		File srcFile = takeScreenShot.getScreenshotAs(OutputType.FILE);

		// Generate a timestamp
		String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());

		// Append the timestamp to the filename
		String fileNameWithTimestamp = "screenshot_" + timestamp + ".png";

		// Construct the destination file path with the unique filename
		File destFile = new File(filepath + File.separator + fileNameWithTimestamp);

		try {
			FileUtils.copyFile(srcFile, destFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return filepath + File.separator + fileNameWithTimestamp;
	}

	public void clickTwoElement(WebElement element, WebElement element2) {
		waitForElementToDisplay(element);
		element.click();
		waitForElementToDisplay(element2);
		element2.click();
	}

	public void scrollToElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public void scrollByPixel(int x, int y) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + x + ", " + y + ");", "");
	}

	public void takeADelay(int i) {
		try {
			Thread.sleep(i * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void refresh() {
		driver.navigate().refresh();
	}

	public void setTextToInputFieldandEnter(WebElement element, String text) {
		waitForElementToDisplay(element);
		element.clear();
		element.sendKeys(text);
		takeADelay(1);
		element.sendKeys(Keys.ENTER); // Press "Enter" key after sending text

	}

}
