package pom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.UiAssesment.Base.ReusableFunctions;

public class AccessoriesPage {

	public WebDriver driver;
	ReusableFunctions rf;

//	constructor
	public AccessoriesPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunctions(driver);
	}

	@FindBy(linkText = "Accessories")
	WebElement accessories;

	@FindBy(xpath = "//div[@class='product-facet__meta-bar-item product-facet__meta-bar-item--sort']/div/button")
	WebElement sortButton;

	@FindBy(id = "sort-by-popover")
	WebElement sortByPopOver;

	@FindBy(xpath = "//div[@class='product-facet__meta-bar-item product-facet__meta-bar-item--sort']/div/sort-by-popover/div/div/label[2]")
	WebElement priceLowToHigh;

	@FindBy(className = "price")
	List<WebElement> priceList;

	public void clickAccessories() {
		rf.clickOnElement(accessories);

	}

	public void clickSortButton() {
		rf.clickOnElement(sortButton);

	}

	public boolean isSortByPopOverIsShown() {
		return sortByPopOver.isDisplayed();
	}

	public void clickPriceLowToHigh() {
		rf.clickOnElement(priceLowToHigh);
	}

	public boolean price() {

		Boolean flag = true;
		List<Integer> price = new ArrayList<Integer>();
		rf.scrollByPixel(0, 500);
		rf.takeADelay(1);

		for (WebElement w : priceList) {
			String[] arr = w.getText().split("₹");// splits the text using rupee symbol
			String int_price = arr[1].replaceAll("[^a-zA-Z0-9 ]", "");// removes comma from string price
			price.add(Integer.parseInt(int_price)); // convert string to int

		}
//check if the price is sorted or not
		for (int i = 1; i < price.size(); i++) {

			if (price.get(i) < price.get(i - 1)) {
				flag = false;
				break;
			}

		}
		return flag;

	}

}
