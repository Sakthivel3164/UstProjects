package pom;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Listeners;

import ust.UiAssesment.Base.ReusableFunctions;

public class ProductList {

	public WebDriver driver;
	ReusableFunctions rf;

//	constructor
	public ProductList(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunctions(driver);
	}

//	text of search result
	@FindBy(className = "boost-sd__search-form-title")
	WebElement jeanText;

	@FindBy(css = "div[class='boost-sd__product-title']")
	List<WebElement> productNames;

	@FindBy(linkText = "ice wash straight leg women's jeans")
	WebElement product;

	public boolean isJeanPageDisplayed() {
		return jeanText.getText().contains("jeans");
	}

	/*
	 * method will check whether each product names contains "JEANS" else returns
	 * false
	 */

	public boolean checkNames() {

		boolean flag = true;
		rf.scrollByPixel(0, 600);
		rf.takeADelay(2);
		for (WebElement w : productNames) {
			if (!w.getText().contains("JEANS") && !w.getText().contains("PANT")) {
				flag = false;
				break;
			}

		}
		return flag;
	}

//	clicks a product and returns the object of cartpage
	public CartPage clickProduct() {
		rf.clickOnElement(productNames.get(0));
		return new CartPage(driver);
	}
}
