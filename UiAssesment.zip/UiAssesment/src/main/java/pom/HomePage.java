package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.UiAssesment.Base.ReusableFunctions;

public class HomePage {
	public WebDriver driver;
	ReusableFunctions rf;

//	constructor
	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunctions(driver);
	}

//	search bar 
	@FindBy(id = "boost-sd__search-widget-init-input-0")
	WebElement searchBar;

//	search product in search bar
	public ProductList searchItem(String data) {
		rf.setTextToInputFieldandEnter(searchBar, data);
		rf.takeADelay(3);
		return new ProductList(driver); // returns the object of productlist page
	}

}
