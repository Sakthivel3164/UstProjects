package utilities;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class XLutility {
	
	FileInputStream f1;
	String path;
	String sheetName;
	XSSFWorkbook wb;
	XSSFSheet sheet;
	XSSFRow row;
	XSSFCell cell;
	
	public XLutility(String path,String sheetName) {
		this.path = path;
        this.sheetName = sheetName;
	}
	
	public int GetRowCount() {
		try {
			f1 = new FileInputStream(path);
			wb =  new XSSFWorkbook(f1);
			sheet = wb.getSheet(sheetName);
			int rowcount = sheet.getLastRowNum();
			wb.close();
            f1.close();
			return rowcount;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public int GetCellCount(int rowNum) {
		try {
			f1 = new FileInputStream(path);
			wb =  new XSSFWorkbook(f1);
			sheet = wb.getSheet(sheetName);
			row = sheet.getRow(rowNum);
			int cellcount = row.getLastCellNum();
			wb.close();
            f1.close();
			return cellcount;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public String GetCellData(int rowNum , int colNum) {
		try {
			f1 = new FileInputStream(path);
            wb =  new XSSFWorkbook(f1);
            sheet = wb.getSheet(sheetName);
            row = sheet.getRow(rowNum);
            cell = row.getCell(colNum);
            DataFormatter df = new DataFormatter();
            String data = df.formatCellValue(cell);
            wb.close();
            f1.close();
            return data;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
