package endpoints;

public class AuthorsRoutes {
	public static String BASE_URI = "https://fakerestapi.azurewebsites.net";
	public static String GET_BASE_PATH ="/api/v1/Authors";
	public static String GET_BASE_PATH_AUTHOR ="/api/v1/Authors/{id}";
	public static String GET_BASE_PATH_BOOK="/api/v1/Authors/authors/books/{idBook}";
	public static String POST_BASE_PATH ="/api/v1/Authors";
	public static String UPDATE_BASE_PATH_AUTHOR ="/api/v1/Authors/{id}";
	public static String DELETE_BASE_PATH_AUTHOR ="/api/v1/Authors/{id}";
}
