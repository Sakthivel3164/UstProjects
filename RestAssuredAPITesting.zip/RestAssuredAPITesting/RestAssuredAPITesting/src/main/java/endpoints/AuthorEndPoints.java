package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload.AuthorModel;

public class AuthorEndPoints {
public static Response createAuthor(AuthorModel payload) {
	RestAssured.useRelaxedHTTPSValidation();
	Response response = RestAssured.given()
			.header("Content-Type",
					"application/json",
					"Accept",
					ContentType.JSON)
										.baseUri(AuthorsRoutes.BASE_URI)
										.basePath(AuthorsRoutes.POST_BASE_PATH)
										.accept(ContentType.JSON)
										.body(payload)
										.when()
										.post();
	return response;
}
public static Response getAllAuthor() {
	RestAssured.useRelaxedHTTPSValidation();
	Response response = RestAssured.given()
			.header("Content-Type",
					"application/json",
					"Accept",
					ContentType.JSON)
										.baseUri(AuthorsRoutes.BASE_URI)
										.basePath(AuthorsRoutes.GET_BASE_PATH)
										.accept(ContentType.JSON)
										.when()
										.get();
	return response;
}
public static Response getSingleAuthor(int id) {
	RestAssured.useRelaxedHTTPSValidation();
	Response response = RestAssured.given()
			.header("Content-Type",
					"application/json",
					"Accept",
					ContentType.JSON)
										.baseUri(AuthorsRoutes.BASE_URI)
										.basePath(AuthorsRoutes.GET_BASE_PATH_AUTHOR)
										.pathParam("id",id)
										.accept(ContentType.JSON)
										.when()
										.get();
	return response;
}
public static Response getSingleAuthorWithBook(int bookid) {
	RestAssured.useRelaxedHTTPSValidation();
	Response response = RestAssured.given()
			.header("Content-Type",
					"application/json",
					"Accept",
					ContentType.JSON)
										.baseUri(AuthorsRoutes.BASE_URI)
										.basePath(AuthorsRoutes.GET_BASE_PATH_BOOK)
										.pathParam("idBook",bookid)
										.accept(ContentType.JSON)
										.when()
										.get();
	return response;
}
public static Response updateAuthor(AuthorModel payload,int id) {
	RestAssured.useRelaxedHTTPSValidation();
	Response response = RestAssured.given()
			.header("Content-Type",
					"application/json",
					"Accept",
					ContentType.JSON
					)
										.baseUri(AuthorsRoutes.BASE_URI)
										.basePath(AuthorsRoutes.GET_BASE_PATH_AUTHOR)
										.pathParam("id",id)
										.accept(ContentType.JSON)
										.body(payload)
										.when()
										.put();
	return response;
}
public static Response deleteAuthor(int id) {
	RestAssured.useRelaxedHTTPSValidation();
	Response response = RestAssured.given()
			.header("Content-Type",
					"application/json",
					"Sever",
					"Kestrel")
										.baseUri(AuthorsRoutes.BASE_URI)
										.basePath(AuthorsRoutes.GET_BASE_PATH_AUTHOR)
										.pathParam("id",id)
										.when()
										.delete();
	return response;
}
}
