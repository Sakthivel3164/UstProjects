package ust.nopcommerce.test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import ust.nopcommerce.base.ExcelHandling;
import ust.nopcommerce.base.ReusableFunctions;
import ust.nopecommerce.pom.HomePagePom;
import ust.nopecommerce.pom.SignupPom;

public class TestRegister {
	WebDriver driver;
	ReusableFunctions rf;
	HomePagePom homePagePom;
	SignupPom signupPom;
	ExtentSparkReporter htmlReporter;
	ExtentReports reports;
	ExtentTest test;

	@BeforeClass
	public void invokeBrowser() {

		driver = ReusableFunctions.invokeBrowser();
		rf = new ReusableFunctions(driver);
		rf.openWebsite("url");
		homePagePom = new HomePagePom(driver, rf);

	}

	@BeforeClass
	public void startReport() {
		htmlReporter = new ExtentSparkReporter("ExtentReportDemo.html");
		reports = new ExtentReports();
		reports.attachReporter(htmlReporter);
		// add environtment variables
		reports.setSystemInfo("OS", "Windows");
		reports.setSystemInfo("Browser", "chrome");
		reports.setSystemInfo("Environment", "QA");
		reports.setSystemInfo("user", "Sakthivel");
		// configuration look
		htmlReporter.config().setDocumentTitle("Extent Report Demo");
		htmlReporter.config().setReportName("Test Report");
		htmlReporter.config().setTheme(Theme.DARK);
		htmlReporter.config().setTimeStampFormat("EEE,MMM dd, yyyy, hh:mm a '('zzz')'");
	}

	@org.testng.annotations.Test(priority = 0)
	public void testNavigateToRegister() {
		test = reports.createTest("validlogin");
		signupPom = homePagePom.clickRegisterButton();

		assertTrue(signupPom.isRegisterHeadingDisplayed());
		assertEquals(driver.getCurrentUrl(), rf.getPropertyValue("registerurl"));
	}

	@org.testng.annotations.Test(priority = 1)
	public void testNullRegister() {
		test = reports.createTest("clickregister");
		assertEquals(signupPom.nullRegister(), rf.getPropertyValue("firstnameerrormsg"));
//		validate whether same page is diplayed after null login
		assertEquals(driver.getCurrentUrl(), rf.getPropertyValue("registerurl"));

	}

//	to get data from excel
	@DataProvider(name = "registration")
	public String[][] getValidData() throws Exception {
		String path = System.getProperty("user.dir") + "/src/test/resources/register.xlsx";
		String sheetName = "Sheet1";
		return ExcelHandling.getExcelData(path, sheetName);
	}

//sign in with valid details
	@org.testng.annotations.Test(dataProvider = "registration", priority = 2)
	public void testValidRegister(String firstName, String lastName, String email, String companyName, String pwd,
			String confirm_pwd)

	{
		test = reports.createTest("validlogin");
		assertTrue(signupPom.validLogin(firstName, lastName, email, companyName, pwd, confirm_pwd));
		assertTrue(signupPom.isContinueButtonDiplayed());

	}

	@AfterMethod
	public void takeScreenshot() {
		ReusableFunctions.takeScreenShot(System.getProperty("user.dir") + "\\screenshot\\");
	}

	@AfterClass()
	public void tearDown() {
		reports.flush();
		System.out.println("Bowser Closing....");
		driver.quit();
	}

}
