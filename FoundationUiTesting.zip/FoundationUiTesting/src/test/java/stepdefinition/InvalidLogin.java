package stepdefinition;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import ust.nopcommerce.base.ReusableFunctions;
import ust.nopecommerce.pom.LoginPageObject;

public class InvalidLogin  {
	WebDriver driver = Hooks.driver;
	ReusableFunctions rf = new ReusableFunctions(driver);
	LoginPageObject loginPageObject = new LoginPageObject(driver, rf);

	@Given("User already open website nopcommerce")
	public void user_already_open_website_nopcommerce() {
		loginPageObject.clickLogin();

	}

	@When("User input {string} as username {string} as password")
	public void user_input_as_username_as_password(String string, String string2) {
		loginPageObject.enterInvalidDetails(string, string2);
	}

	@Then("User get {string} as error message")
	public void user_get_as_error_message(String string) {
		assertTrue(loginPageObject.isErrorMessageDisplayed());
	}
}
