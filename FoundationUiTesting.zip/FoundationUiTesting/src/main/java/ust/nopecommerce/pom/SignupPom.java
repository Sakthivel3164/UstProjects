package ust.nopecommerce.pom;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import ust.nopcommerce.base.ReusableFunctions;

public class SignupPom {
	WebDriver driver;
	ReusableFunctions rf;

	public SignupPom(WebDriver driver, ReusableFunctions rf) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.rf = rf;

	}

	@FindBy(tagName = "h1")
	WebElement registerHeading;

	@FindBy(id = "register-button")
	WebElement registerButton;

	@FindBy(css = "span[id='FirstName-error']")
	WebElement firstNameErrormsg;
	
	@FindBy(name = "Gender")
	WebElement radioButton;
	
	@FindBy(id = "FirstName")
	WebElement firstNameInputField;
	
	@FindBy(xpath = "//input[@id='LastName']")
	WebElement lastNameInputField;
	
	@FindBy(name="DateOfBirthDay")
	WebElement day;
	
	@FindBy(name="DateOfBirthMonth")
	WebElement month;
	
	@FindBy(name="DateOfBirthYear")
	WebElement year;
	
	@FindBy(id = "Email")
	WebElement emailInputField;
	
	@FindBy(id = "Company")
	WebElement companyNameInputField;
	
	@FindBy(xpath = "//input[@id='Password']")
	WebElement passwordField;
	
	@FindBy(xpath = "//input[@id='ConfirmPassword']")
	WebElement confirmPasswordField;
	
//	registration success message
	@FindBy(className ="result")
	WebElement successMessage;
	
	@FindBy(className = "buttons")
	WebElement continueButton;

	
	
	
	

	public boolean isRegisterHeadingDisplayed() {
		return registerHeading.isDisplayed();
	}

	public String nullRegister() {
		rf.scrollToElement(registerHeading);
		rf.clickOnElement(registerButton);
		return firstNameErrormsg.getText();

	}
	
//	entre valid details and submit
	public boolean validLogin(String firstName, String lastName, String email, String companyName, String pwd,
			String confirm_pwd)
	{
		rf.clickOnElement(radioButton);
		rf.setTextToInputField(firstNameInputField, firstName);
		rf.setTextToInputField(lastNameInputField, lastName);
		Select s1 = new Select(day);
		Select s2 = new Select(month);
		Select s3 = new Select(year);
		s1.selectByIndex(10);
		s2.selectByValue("10");
		s3.selectByVisibleText("2000");
		rf.setTextToInputField(emailInputField, email);
		rf.setTextToInputField(companyNameInputField, companyName);
		rf.setTextToInputField(passwordField, pwd);
		rf.setTextToInputField(confirmPasswordField, confirm_pwd);
		rf.clickOnElement(registerButton);
		
		return successMessage.isDisplayed();
		
	}
	public boolean isContinueButtonDiplayed()
	{
		return continueButton.isDisplayed();
	}
//

}
