package ust.nopecommerce.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.nopcommerce.base.ReusableFunctions;

public class LoginPageObject {
	WebDriver driver;
	ReusableFunctions rf;

	public LoginPageObject(WebDriver driver, ReusableFunctions rf) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.rf = rf;

	}
	@FindBy(className = "email")
	WebElement emailInputField;
	
	@FindBy(xpath  = "//div[@class='message-error validation-summary-errors']")
	WebElement errorMsg;
	
	@FindBy(linkText = "Log in")
	WebElement login;
	
	@FindBy(id = "Password")
	WebElement passwordInputField;
	
	@FindBy(xpath = "//button[@class='button-1 login-button']")
	WebElement submitButton;
	
	public void clickLogin()
	{
		rf.clickOnElement(login);
	}
	public void enterInvalidDetails(String email,String pwd)
	{
		rf.setTextToInputField(emailInputField, email);
		rf.setTextToInputField(passwordInputField, pwd);
		rf.clickOnElement(submitButton);
	}
	public boolean isErrorMessageDisplayed()
	{
		return errorMsg.isDisplayed();
	}
	
	public void validLogin(String email,String pwd)
	{
		rf.setTextToInputField(emailInputField, email);
		rf.setTextToInputField(passwordInputField, pwd);
		rf.clickOnElement(submitButton);
	}
}
