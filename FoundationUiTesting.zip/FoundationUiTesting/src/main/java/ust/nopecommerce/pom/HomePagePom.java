package ust.nopecommerce.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ust.nopcommerce.base.ReusableFunctions;

public class HomePagePom {
	WebDriver driver;
	ReusableFunctions rf;

	public HomePagePom(WebDriver driver, ReusableFunctions rf) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.rf = rf;

	}

//	register button on top of home page
	@FindBy(linkText = "Register")
	WebElement registerButton;

	

	public SignupPom clickRegisterButton() {
		rf.clickOnElement(registerButton);
		return new SignupPom(driver, rf);
	}

	
}
