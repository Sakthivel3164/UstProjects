package base;

import java.io.FileInputStream;
import java.util.Properties;

public class FileIO {
private static Properties properties;
	
	public static Properties getProperties(){
		if(properties==null){
			properties = new Properties();
			try {
				FileInputStream fis = new FileInputStream("D:\\Workspaces\\UST SDET FEB-2024\\SeleniumDemos\\src\\test\\resources\\objectrepository\\configuration.properties");
				properties.load(fis);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return properties;
	}


}
