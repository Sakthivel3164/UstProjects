package PageFactory;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import base.ReusableFunction;

public class Login {
	WebDriver driver;
	ReusableFunction reusableFunction;
	
	public Login(WebDriver driver)
	{
		this.driver = driver;
		this.reusableFunction = new ReusableFunction(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="user")
	private WebElement username;
	@FindBy(id="pass")
	private WebElement password;
	@FindBy(id="btnLogin")
	private WebElement login;
	
	@Test
	public void enterUsername(String uname)
	{
//		reusableFunction.waitForElementToDisplay(username);
		reusableFunction.setTextToInputField(username, uname);
		assertEquals(false, null);
	}
	public void enterPassword(String pwd)
	{
//		reusableFunction.waitForElementToDisplay(username);
		reusableFunction.setTextToInputField(password, pwd);
	}
	public void clickLogin()
	{
		reusableFunction.clickOnElement(login);
	}
	

}
