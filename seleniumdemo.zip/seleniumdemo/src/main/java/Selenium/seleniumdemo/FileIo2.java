package Selenium.seleniumdemo;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class FileIo2 {
	static FileInputStream stream;
	static Properties properties;
	
	public static String getProperties()
	{
		if(properties==null)
		{
			properties = new Properties();
		}
		try {
			
			stream = new FileInputStream("C:\\Users\\268845\\Documents\\UnitTesting\\seleniumdemo\\src\\test\\resources\\ObjectRepository\\configuration.properties");
		properties = new Properties();
		properties.load(stream);
		return properties.getPrope();
		
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
		
	}

}
