package Selenium.seleniumdemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class FileIO {
	static FileInputStream stream;
	static Properties properties;
	
	public static String getProperties(String key)
	{
		try {
			
			stream = new FileInputStream("C:\\Users\\268845\\Documents\\UnitTesting\\seleniumdemo\\src\\test\\resources\\ObjectRepository\\configuration.properties");
		properties = new Properties();
		properties.load(stream);
		return properties.getProperty(key);
		
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
		
	}
	public static void main(String[] args) {
		System.out.println(getProperties("browser"));
	}

}
