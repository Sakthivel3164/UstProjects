package Selenium.seleniumdemo;

import org.apache.commons.compress.compressors.brotli.BrotliUtils;
import org.openqa.selenium.WebDriver;

public class StarBucks {
	public static WebDriver driver;
	
	public  void starBucks()
	{
		driver = BrowUt
	}

}
