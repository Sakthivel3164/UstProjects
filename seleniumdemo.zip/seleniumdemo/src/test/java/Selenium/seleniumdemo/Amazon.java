package Selenium.seleniumdemo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Amazon {
	public static WebDriver driver;

	@Test
	public void amazon() {
		driver = BrowserConfiguration.setup();

		driver.get("https://amazon.in/");
		Actions a = new Actions(driver);
		a.moveToElement(driver.findElement(By.className("nav-line-1-container"))).build().perform();
		driver.findElement(By.linkText("Your Recommendations")).click();
		driver.findElement(By.name(null));

		for (int i = 0; i < 20; i++) {
			if (i != 0 && i % 4 == 0) {
				try {
					Thread.sleep(2000);
					
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
			WebElement e = driver
					.findElement(By.xpath("//*[@id=\"p13n-asin-index-" + i + "\"]/div/div[2]/div/span/div"));
			String s = e.getText();
			System.out.println(s + "\n");
		}

//		System.out.println(list.size());

	}

}
