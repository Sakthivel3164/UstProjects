package Selenium.seleniumdemo;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReusableFunctions {
	
	private static WebDriver driver;
	private WebDriverWait wait;
	public static Properties properties;
	
	public ReusableFunctions(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		properties = FileIO.getProperties(null);
	}
	
	public static WebDriver invokeBrowser()
	{
		browser_choice = properties.getProperty("browser");
	}

}
