package Selenium.seleniumdemo;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class NavigationalCommands {
	public static WebDriver driver;
	@Test
	public void navigationalCommands()
	{
		driver = BrowserConfiguration.setup();
//		to open all url
		driver.get("https://www.google.com");
		driver.navigate().to("https://www.amazon.com/");
		driver.navigate().back();
		driver.navigate().forward();
//		driver.navigate().refresh();
		
//		print the title of the page
		String title = driver.getTitle();
		System.out.println(title);
		
//		print current url
		
		String url = driver.getCurrentUrl();
		System.out.println(url);
		
		driver.close();//to close all the browsers
		driver.quit();//to close current browser
		
	}
	

}
