package Selenium.seleniumdemo;

import org.junit.Ignore;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.testng.annotations.Test;

@Ignore
@Test
public class EbayTest {
	WebDriver driver;
	@Ignore
	public void ebaySearch()
	{
		driver = BrowserSetup.chromeSetup();
		driver.get("https://www.ebay.com/");
		By searchBox = RelativeLocator.with(By.cssSelector("input[type='text']")).toLeftOf(By.cssSelector("select[id='gh-cat']"));
		driver.findElement(searchBox).sendKeys("Samsung");
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		Actions actions  =new Actions(driver);
		
	}

}
