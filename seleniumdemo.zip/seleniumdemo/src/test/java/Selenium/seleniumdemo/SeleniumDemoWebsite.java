package Selenium.seleniumdemo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class SeleniumDemoWebsite {
	public static WebDriver driver;

	@Test
	public void seleniumDemo() {
		driver = BrowserConfiguration.setup();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.findElement(By.linkText("Open New Seperate Windows")).click();
		driver.findElement(By.cssSelector("button[class=\"btn btn-primary\"]")).click();

		String parent = driver.getWindowHandle();

		Set<String> set = driver.getWindowHandles();
		System.out.println(set);
		for(String handle:set)
		{
			if(!handle.equals(parent))
			{
				driver.switchTo().window(handle);
				System.out.println("Child window title: "+driver.getTitle());
//				click downloads here
				driver.findElement(By.linkText("Downloads")).click();
//				close the child window
				driver.close();
			}
//			switch back to parent window
			driver.switchTo().window(parent);
			System.out.println("Parent window title: "+driver.getTitle());
		}
		List<String> list = new ArrayList<String>(set);
		for (int i = 0; i < list.size(); i++)

		{
			if(!parent.equals(list.get(i)))
			{
				driver.switchTo().window(list.get(i));
				driver.findElement(By.linkText("Downloads")).click();
				driver.close();
			}
			driver.switchTo().window(parent);
			System.out.println("Parent window title: "+driver.getTitle());

		}
	}

}
