package Selenium.seleniumdemo;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;

public class BrowserConfiguration {
	@org.testng.annotations.Test
	public static  WebDriver setup() {
		ChromeOptions options  = new ChromeOptions();
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
//		options.addArguments("Disable notifications");
//		options.addArguments("start maximized");
		
		
		WebDriver driver = new ChromeDriver(options);
		return driver;
		
		
	}
	

}
