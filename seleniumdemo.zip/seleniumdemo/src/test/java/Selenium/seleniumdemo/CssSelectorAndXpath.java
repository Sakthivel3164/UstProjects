package Selenium.seleniumdemo;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.reporters.jq.TimesPanel;

public class CssSelectorAndXpath {
	public static WebDriver driver;
	
     @Test
	public void cssSelectorAndXpath() {
		driver = BrowserConfiguration.setup();
		driver.get("https://www.mycontactform.com/");
		driver.findElement(By.linkText("Sample Forms")).click();
		driver.findElement(By.cssSelector("input[name=\"email_to[]\"][value=\"1\"]")).click();
		driver.findElement(By.xpath("//input[@name=\"subject\" and @size=\"20\"]")).sendKeys("Java");
		driver.findElement(By.xpath("//input[@name=\"email\" and @size=\"20\"]")).sendKeys("sakthi@gmail.com");
		driver.findElement(By.xpath("//input[@name=\"email\" and @size=\"20\"]")).sendKeys("sakthi@gmail.com");
		driver.findElement(By.xpath("//input[@name=\"q1\" and @size=\"20\"]")).sendKeys("sakthi@gmail.com");
		driver.findElement(By.xpath("//textarea[@name=\"q2\" and @cols=\"50\"]")).sendKeys("jwdhjkhdjhkejhfk32hcnnncehfiohiorghiohnkdnvklnevlnemnemlnfklenljrhfleknknc");
		
		Select s = new Select(driver.findElement(By.xpath("//select[@name=\"q3\" and @id=\"q3\"]")));
		s.selectByIndex(1);
	
		
		driver.findElement(By.cssSelector("input[id='q4'][value='First Option']")).click();
		driver.findElement(By.cssSelector("input[id='q4'][value='Second Option']")).click();
		driver.findElement(By.cssSelector("input[id='q4'][value='Third Option']")).click();
		driver.findElement(By.cssSelector("input[id='q4'][value='Fourth Option']")).click();
		driver.findElement(By.cssSelector("input[id='q4'][value='Fifth Option']")).click();
		
		
		
		driver.findElement(By.xpath("//input[@name=\"q5\" and @value=\"Yes\"]")).click();
		
//		
//		driver.findElement(By.xpath("//input[@name=\"checkbox6[]\" and @value=\"First Check Box\"]")).click();
//		driver.findElement(By.xpath("//input[@name=\"checkbox6[]\" and @value=\"Second Check Box\"]")).click();
//		driver.findElement(By.xpath("//input[@name=\"checkbox6[]\" and @value=\"Third Check Box\"]")).click();
//		driver.findElement(By.xpath("//input[@name=\"checkbox6[]\" and @value=\"Fourth Check Box\"]")).click();
//		driver.findElement(By.xpath("//input[@name=\"checkbox6[]\" and @value=\"Fifth Check Box\"]")).click();
//		
//		
//		driver.findElement(By.xpath("//input[@id=\"q7\"]")).sendKeys("17/08/2023");
//		
//		new Select(driver.findElement(By.xpath("//select[@id=\"q8\"]"))).selectByValue("CA");
//		
////		new Select(driver.findElement(By.xpath("//select[@name=\"q11_title\"]"))).selectByValue("Dr");
//		driver.findElement(By.xpath("//input[@name=\"q11_first\"]")).sendKeys("Sakthi");
//		driver.findElement(By.xpath("//input[@name=\"q11_last\"]")).sendKeys("Vel");
//		new Select(driver.findElement(By.xpath("//select[@name=\"q12_month\"]"))).selectByValue("7");
//		new Select(driver.findElement(By.xpath("//select[@name=\"q12_day\"]"))).selectByValue("30");
//		new Select(driver.findElement(By.xpath("//select[@name=\"q12_year\"]"))).selectByValue("1999");
//		
//		List<WebElement> list = driver.findElements(By.cssSelector("input[type=\"checkbox\"]"));
//		System.out.println(list.size());
////		System.out.println(list.get(0));
//		for(WebElement w:list)
//		{
//			w.click();
//		}
		
		List<WebElement> list2 = driver.findElements(By.xpath("//div[@id=\"left_col_top\"]/ul/li"));
		System.out.println(list2.size());
		int k=0;

		for(int i=1;i<=list2.size();i++)
		{
			List<WebElement> list3 = driver.findElements(By.xpath("//div[@id=\"left_col_top\"]/ul["+i+"]/li"));
			for(int j=1;j<=list3.size();j++)
			{
				int n = k++;
				
				 driver.findElement(By.xpath("//div[@id=\"left_col_top\"]/ul["+i+"]/li["+j+"]")).click();
				 File file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				 try {
						FileUtils.copyFile(file, new File(System.getProperty("user.dir")+"/screenshots/"+"img"+n+".jpg"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						
				 
			}
		}
		
//		driver.get("https://www.amazon.in/");
//		File file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//		try {
//			FileUtils.copyFile(file, new File(System.getProperty("user.dir")+"/screenshots/"+"img.jpg"));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		

		
		
		
		
		
		

	}

}
}
