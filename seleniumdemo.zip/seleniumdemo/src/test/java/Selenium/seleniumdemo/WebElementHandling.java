package Selenium.seleniumdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class WebElementHandling {
	public static WebDriver driver;
	@Test
	public void webElementHandling()
	{
		driver = BrowserConfiguration.setup();
		driver.get("https://www.mycontactform.com/");
		WebElement sampleformslink = driver.findElement(By.linkText("Sample Forms"));
		sampleformslink.click();
//		WebElement element =  driver.findElements(By.linkText("Hello"));
//		driver.findElement(By.id("user")).sendKeys("Sakthi");
//		driver.findElement(By.name());
		driver.findElement(By.cssSelector("input[value=\"1\"][name=\"email_to[]\"]")).click();
//		driver.findElement(By.cssSelector("input[id=\"q4\"][value=\"First Option\"]")).click();
		
		
		
		
	}

}
