package Selenium.seleniumdemo;

import org.openqa.selenium.WebDriver;

public class BrowserUtil {
	public static WebDriver browserUtil() {
		String s = FileIO.getProperties("browser");
		if(s.equals("chrome"))
		{
			return BrowserSetup.chromeSetup();
		}
		else if(s.equals("edge"))
		{
			return BrowserSetup.edgeSetup();
		}
		else if(s.equals("firefox"))
		{
			return BrowserSetup.firefoxSetup();
		}
		return null;
	}
	

}
