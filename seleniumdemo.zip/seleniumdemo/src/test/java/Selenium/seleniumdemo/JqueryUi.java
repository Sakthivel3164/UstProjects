package Selenium.seleniumdemo;

import java.awt.Desktop.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class JqueryUi {
	public static WebDriver driver;

	@Test
	public void jqueryUi() {
		driver = BrowserUtil.browserUtil();
		driver.get("https://jqueryui.com/");

		driver.findElement(By.linkText("Droppable")).click();
		WebElement frame = driver.findElement(By.className("demo-frame"));
		driver.switchTo().frame(frame);
		WebElement drag = driver.findElement(By.id("draggable"));
		WebElement drop = driver.findElement(By.id("droppable"));

//	    drag and drop using mouse actions

		Actions a = new Actions(driver);
		a.clickAndHold(drag).moveToElement(drop).release(drop).build().perform();
	}

}
