package Selenium.seleniumdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.testng.annotations.Test;

public class GoogleTest {

	WebDriver driver;

	@Test
	public void googleSearch() {
		driver = BrowserSetup.chromeSetup();
		driver.get("https://www.google.com/");
		By googlesearch = RelativeLocator.with(By.cssSelector("textarea[class=\"gLFyf\"]"))
				.above(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]"));
		driver.findElement(googlesearch).sendKeys("seleniium");

//		driver.findElement(By.cssSelector("textarea[class=\"gLFyf\"]")).sendKeys("Selenium");

		driver.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]")).click();
	}

}
