package Selenium.seleniumdemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class BrowserSetup {
	@org.testng.annotations.Test
	public static  WebDriver chromeSetup() {
		ChromeOptions options  = new ChromeOptions();
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
//		options.addArguments("Disable notifications");
//		options.addArguments("start maximized");
		
		
		WebDriver driver = new ChromeDriver(options);
		return driver;

}
	public static WebDriver edgeSetup()
	{
		EdgeOptions edgeOptions = new EdgeOptions();
		System.setProperty("webdriver.edge.driver", null);
		WebDriver driver2 = new EdgeDriver(edgeOptions);
		return driver2;
		
	}
	public static WebDriver firefoxSetup()
	{
		FirefoxOptions firefoxOptions = new FirefoxOptions();
		WebDriver driver3 = new FirefoxDriver(firefoxOptions);
		return driver3;

	}
}
