package Selenium.seleniumdemo;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class AlertHandling {
	public static WebDriver driver;
	@Test
	public void alertHandling()
	{
		driver = BrowserConfiguration.setup();
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.findElement(By.cssSelector("button[class=\"btn btn-danger\"]")).click();
		Alert a = driver.switchTo().alert();
		a.accept();
		driver.findElement(By.linkText("Alert with Textbox ")).click();
		Alert a1 = driver.switchTo().alert();
		a1.sendKeys("Hello");
		
	}

}
