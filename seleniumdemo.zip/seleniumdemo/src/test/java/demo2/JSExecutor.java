package demo2;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JSExecutor {
	public static WebDriver driver;
	
	public void navigationCommands()
	{
		driver.get("https://www.myntra.com/");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");//1000 pixel downwards
//		scroll to element
		WebElement element = driver.findElement(By.xpath("(//a[@href='/my/orders')[3]"));
		js.executeScript("arguments[0].scrollIntoView();",element);
//		click
		js.executeScript("arguments[0].click();", element);
//		to enter
		
	}

}
