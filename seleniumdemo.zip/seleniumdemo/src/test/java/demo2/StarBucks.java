package demo2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Selenium.seleniumdemo.BrowserUtil;

public class StarBucks {
	public static WebDriver driver;
	@Test
	public static void starBucks()
	{
		driver = BrowserUtil.browserUtil();
		driver.get("https://www.starbucks.in/dashboard");
		driver.findElement(By.linkText("Gift")).click();
	}

}
