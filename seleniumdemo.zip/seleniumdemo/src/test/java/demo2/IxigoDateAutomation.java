package demo2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Selenium.seleniumdemo.BrowserSetup;

public class IxigoDateAutomation {

	public static WebDriver driver;

	@Test
	public static void dateAutomation() {
		String requiredMonth = "November";
		driver = BrowserSetup.chromeSetup();
		driver.get("https://www.ixigo.com/");
		driver.findElement(By.xpath("/html/body/main/div[2]/div[1]/div[3]/div[2]/div[2]/div[1]/div/div/div/div/p[2]"))
				.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement e = driver.findElement(By.xpath(
				"/html/body/main/div[2]/div[1]/div[3]/div[2]/div[2]/div[3]/div/div[1]/div[1]/button[2]/span[1]"));
		String[] s = e.getText().split(" ");
		String currentMonth = s[0];
		
//		Comparing two months
		
		while(!currentMonth.equals(requiredMonth))
		{
			driver.findElement(By.xpath("/html/body/main/div[2]/div[1]/div[3]/div[2]/div[2]/div[3]/div/div[1]/div[1]/button[3]")).click();
		    e = driver.findElement(By.xpath(
					"/html/body/main/div[2]/div[1]/div[3]/div[2]/div[2]/div[3]/div/div[1]/div[1]/button[2]/span[1]"));
			 s = e.getText().split(" ");
			currentMonth = s[0];
			
		}
		
		

	}

}
