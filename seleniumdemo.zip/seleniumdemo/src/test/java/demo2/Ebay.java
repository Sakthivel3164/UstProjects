package demo2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import base.ReusableFunction;

public class Ebay {

	ReusableFunction reusableFunction;

	@Test
	public void chromeSetup() {
		ChromeOptions options = new ChromeOptions();
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		options.addArguments("--Disable-notifications");

		WebDriver driver = new ChromeDriver(options);
		PageFactory.initElements(driver, this);
		driver.get("https://www.ebay.com ");

	}

	@FindBy(xpath =   "//*[@id=\"gh-ac\"]")
	public static WebElement searchBox;

	@FindBy(xpath  = "//*[@id=\"gh-cat\"]")
	public static WebElement dropdown;

	

	@Test
	public static void searchElement() {
		searchBox.click();
		searchBox.sendKeys("Selenium");
	}

	@Test
	public static void selectBook() {
		Select s = new Select(dropdown);
		s.selectByIndex(4);
	}
	
	@FindBy(xpath =  "//*[@id=\"gh-btn\"]")
	public static WebElement searchButton;

	@Test
	public static void clickButton() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		searchButton.click();
	}

}
