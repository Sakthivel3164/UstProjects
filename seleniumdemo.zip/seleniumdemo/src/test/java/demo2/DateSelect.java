package demo2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Selenium.seleniumdemo.BrowserSetup;

public class DateSelect {
	public static WebDriver driver;

	@Test
	public static void dataSelect() {
//		user entered date
		String dt = "18/03/2024";
		String month = "MAR";
		String year = "2024";
		String mon_year = month+" "+year;
		driver = BrowserSetup.chromeSetup();
		driver.get("https://www.easemytrip.com/");
//		Clicking the date
		driver.findElement(By.cssSelector("div[id=\"dvfarecal\"]")).click();
		
	List<WebElement> mon = driver.findElements(By.xpath("(//div[@class='month2'])[1]"));
//	for(WebElement w:mon)
//	{
//		String mon_arr = w.getText();
//		System.out.println(mon_arr);
//		if(!mon_arr.equals(mon_year))
//		{
//			
//			driver.findElement(By.xpath("//*[@id=\"img2Nex\"]")).click();
//			try {
//				Thread.sleep(3000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			mon = driver.findElements(By.xpath("(//div[@class='month2'])[1]"));
//			try {
//				Thread.sleep(3000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			System.out.println(w.getText());
//		}
//		else
//			break;
	
	for(int i=1;i<=12;i++)
	{
		String mon_arr =  mon.get(0).getText();
		if(mon_arr.equals(mon_year))
		{
			break;
		}
		else
		{
			
			driver.findElement(By.xpath("//*[@id=\"img2Nex\"]")).click();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			mon = driver.findElements(By.xpath("(//div[@class='month2'])[1]"));
		}
	}
//}
//		Storing available date in list
//		List<WebElement> elements = driver
//				.findElements(By.xpath("//li[not (contains(@class, 'old-dt')) and @style='visibility:show']"));
		List<WebElement> elements = driver
				.findElements(By.xpath("//li[@style='visibility:show']"));
		for (int i = 0; i < elements.size(); i ++) {
//			Removing price from date text
			System.out.println(elements.get(i).getText()+" :80");
			String[] arr = elements.get(i).getText().split("\n");
//			concatinating day with month and year
			String date = arr[0] + "/06/2024";
			System.out.println(date);
//			checking obtained date is equal to user entered date
			if (date.equals(dt)) {
				System.out.println(date+": loop");
				String xpathExp = String.format("//li[contains(@id,'%s')]", date);
				System.out.println(xpathExp);
				try {
				driver.findElement(By.xpath(xpathExp)).click();
				}
				catch (Exception e) {
					System.out.println("Cant click");
				}
			}
		}

	}
}
