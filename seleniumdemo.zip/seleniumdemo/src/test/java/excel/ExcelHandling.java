package excel;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelHandling {
	@Test
	public void excelHandling() throws Exception
	{
		;
		try {
			FileInputStream fileInputStream = new FileInputStream("C:\\Users\\268845\\Documents\\UnitTesting\\seleniumdemo\\Testdata\\testdata.xlsx");
//			apache poi - handle excel file
//			xlxs-XSSFworkbook
//			xls - HSSFworkbook --->poi library
			Workbook workbook = new XSSFWorkbook(fileInputStream);
			Sheet sheet = workbook.getSheet("Sheet1");
			int rowCount = sheet.getPhysicalNumberOfRows();//to get used row count
			for(int i=0;i<2;i++)
			{
				Row row = sheet.getRow(i);
				int colCount = row.getPhysicalNumberOfCells();
				String data = row.getCell(0).getStringCellValue();
				System.out.println(data);
			}
			//to get used cell count
//			System.out.println("Total number of rows used: "+rowCount);
//			System.out.println("Total number of columns: "+colCount);
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}

}
