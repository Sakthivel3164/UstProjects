package testCases;

import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import base.ReusableFunction;

public class LoginTestCases {

	private WebDriver driver;
    private ReusableFunction reusableFunction;
	@BeforeClass
	public void beforeTest() {
		driver = ReusableFunction.invokeBrowser();
		reusableFunction = new ReusableFunction(driver);
		
	}
	 @Test
	    public void openTestSite() {
	        // Use the method to navigate to a URL
	        reusableFunction.openWebsite("testSiteURL");
	        //use assertions
	    }

}
