package ustCareers;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CareersPo {
	WebDriver driver;
	WebDriverWait wait;

	public CareersPo(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		PageFactory.initElements(driver, this);

	}
//	locate cookiesButton

	@FindBy(id = "onetrust-accept-btn-handler")
	WebElement cookies;

//	locate India careers button
	@FindBy(linkText = "India Careers")
	WebElement indiaCareers;

//	locate job searchbox
	@FindBy(className = "form-control")
	WebElement jobSearchBox;

//	 searchbutton for job search
	@FindBy(css = "button[data-original-title]")
	WebElement jobSearchButton;
//location Trivandrum
	@FindBy(css = "span[title=\"Location\"]")
	WebElement loc;
	@FindBy(css = "input[type=\"checkbox\"][value=\"Thiruvananthapuram\"]")
	WebElement trivandrum;

//	experience
	@FindBy(xpath = "//*[@id=\"search-panel\"]/div/div[1]/form/div/div[3]/div/span")
	WebElement exp;

	@FindBy(css = "input[value=\"4\"]")
	WebElement year;

//	location in searched job list
//	@FindBy(className = "li[class=\"location-text\"]")
//	WebElement locationText;

	public void clickCookies() {
		cookies.click();
	}

//	click India careers
	public void clickIndiaCareers() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		indiaCareers.click();

	}
//	open new tab and search test automation in job

	public void searchTestAutomation(String s) {
		String parent = driver.getWindowHandle();
		Set<String> handles = driver.getWindowHandles();

		for (String string : handles) {
			if (!string.equalsIgnoreCase(parent)) {
				driver.switchTo().window(string);
				break;
			}

		}
		wait.until(ExpectedConditions.visibilityOf(jobSearchBox));
		jobSearchBox.sendKeys(s);

	}

	public void locationTrivandrum() {
		wait.until(ExpectedConditions.elementToBeClickable(loc));
		loc.click();
		trivandrum.click();
	}
//	experience

	public void selectExperince() {
		wait.until(ExpectedConditions.elementToBeClickable(exp));
		exp.click();
		year.click();

//		By search = RelativeLocator.with((By) jobSearchButton).near(exp);
//		driver.findElement(search).click();

	}

//	click job search button
	public void clickJobSearchButton() {
		jobSearchButton.click();

	}

//	validate by location text

	public boolean validateLocationFromJobs() {
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		List<WebElement> location = driver.findElements(By.cssSelector("li[class=\"location-text\"]"));
		for (WebElement e : location) {
			if(!e.getText().equalsIgnoreCase("Thiruvananthapuram"))
				return false;
		}
		return true;
	}
//	validate by experince
	
	public boolean validateExperience()
	{
		List<WebElement> experience = driver.findElements(By.className("list-job"));
		for(WebElement e:experience)
		{
			System.out.println(e.getText());
		}
		return true;
	}

}