package myntraTest;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import myntraLocating.Myntra;

public class TestMyntra {
	WebDriver driver;
	Myntra myntra;

	@BeforeClass
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		WebDriver driver = new ChromeDriver(options);
		
		
		driver.manage().window().maximize();
		driver.get("https://www.myntra.com");
		myntra = new Myntra(driver);

	}
	@Test
	
	public void testSearchBluetoothHeadphone()
	{
		myntra.searchBluetoothHeadphone("Bluetooth Headphone");
	}
	@Test
	public void testWhatsNew()
	{
		myntra.clickWhatsNew();
	}
	
	@Test
	public void testTCheckProduct()
	{
		String prodName = myntra.checkProductName();
		assertEquals(prodName.toLowerCase(), "pebble");
	}

}
