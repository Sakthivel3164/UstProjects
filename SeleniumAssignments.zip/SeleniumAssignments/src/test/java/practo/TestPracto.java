package practo;

import static org.testng.Assert.assertTrue;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestPracto {
	WebDriver driver;
	PractoPo po;

	int screenShotCounter;

	@BeforeClass
	public void setup() {
		EdgeOptions options = new EdgeOptions();
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		options.addArguments("--disable-notifications");
		driver = new EdgeDriver(options);
		driver.manage().window().maximize();

		driver.get("https://www.practo.com/");
		po = new PractoPo(driver);
	}

	@AfterMethod
	private void takeScreenshot(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			screenShotCounter++;
			try {
				FileUtils.copyFile(screenshot,
						new File(System.getProperty("user.dir") + "/screenshots/" + screenShotCounter + ".jpg"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	@Test(priority = 0)
	public void testSearch() throws InterruptedException
	{
		po.searchLocation("Thiruvananthapuram");
		
	}
	@Test(priority = 1)
	public void testPhysician() throws InterruptedException
	{
		 po.searchPhysician("Physician");
	}
	@Test(priority = 2)
	public void testIsSearching() throws InterruptedException
	{
		String s = po.isSearching();
		assertTrue(po.isSearching().equals("Doctors in Thiruvananthapuram"),"New page not found");
	}
	
}
