package practo;

import java.awt.RenderingHints.Key;
import java.time.Duration;

import org.apache.commons.math3.analysis.function.Exp;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PractoPo {
	WebDriver driver;
	WebDriverWait wait;

	public PractoPo(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		PageFactory.initElements(driver, this);

	}

//	location
	@FindBy(css = "input[placeholder='Search location']")
	WebElement locationBox;

//	location
	@FindBy(className = "c-omni-suggestion-item__content__title")
	WebElement location;

//	doctaors searchbox
	@FindBy(css = "input[placeholder='Search doctors, clinics, hospitals, etc.']")
	WebElement doctorSerachBox;
//	physician dropdown
	@FindBy(xpath = "//*[@id=\"c-omni-container\"]/div/div[2]/div[2]/div[1]/div[1]")
	WebElement physicanSearch;

//	doctors in trivandrum paragraph
	@FindBy(xpath = "//p[@class='u-jumbo-font u-bold']")
	WebElement doctorsInTvm;

//	clear default location and search new loc
	public void searchLocation(String s) throws InterruptedException {
		locationBox.clear();
		locationBox.clear();
		Thread.sleep(1000);
		locationBox.sendKeys(s);

		Thread.sleep(3000);
		location.click();

	}

//	search physician
	public void searchPhysician(String s) throws InterruptedException {
		Thread.sleep(2000);
		doctorSerachBox.sendKeys(s);
		Thread.sleep(2000);
		doctorSerachBox.sendKeys(Keys.ENTER);
//		physicanSearch.click();

	}

//	validate seraching
	public String isSearching() throws InterruptedException {
		Thread.sleep(10000);
		return doctorsInTvm.getText();

	}

}
