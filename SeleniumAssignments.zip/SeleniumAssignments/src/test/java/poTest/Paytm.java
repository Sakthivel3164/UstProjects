package poTest;

import static org.testng.Assert.assertTrue;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class Paytm {
	WebDriver driver;

	@Test
	public void checkPrivacyPolicyExist() throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		options.addArguments("--disable-notifications");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();

		driver.get("https://paytm.com/");
		String parent = driver.getWindowHandle();
		System.out.println(driver.getCurrentUrl());
		Set<String> handles = driver.getWindowHandles();
		driver.findElement(By.cssSelector("div[class=\"_1YPz_\"]")).click();

		WebElement frame1 = driver.findElement(By.cssSelector("iframe[scrolling=\"no\"]"));
		driver.switchTo().frame(frame1);
		WebElement frame = driver.findElement(By.id("oauth-iframe"));
		driver.switchTo().frame(frame);

		Thread.sleep(5000);
		WebElement privacy = driver.findElement(By.xpath("//div[@class=\"_3NG4-yOlawf2yCGLW1iqWa\"][1]"));
		privacy.click();
		
		for(String s:handles)
		{
			if(!s.equalsIgnoreCase(parent))
			{
				driver.switchTo().window(s);
				break;
			}
		}
		Thread.sleep(10000);
		System.out.println(driver.getCurrentUrl());

//		---------------------------------------
//		Child Window

//		assertTrue(privacy.isDisplayed());

	}

}
