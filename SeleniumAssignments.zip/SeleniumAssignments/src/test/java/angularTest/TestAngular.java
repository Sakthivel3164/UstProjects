package angularTest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import angularLocating.AngularLocating;
import ebayLocating.EbayPO;

public class TestAngular {
	WebDriver driver;
	AngularLocating locating;

	@BeforeClass
	public void setup() {
		ChromeOptions options = new ChromeOptions();
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		options.addArguments("--disable-notifications");
		options.addArguments("--start-maximise");
		driver = new ChromeDriver(options);
//		driver.manage().window().maximize();

		driver.get("https://angular-university.io/ ");
		locating = new AngularLocating(driver);
	}
	
	@Test
	public void testClickMyCourse()
	{
		locating.clickMyCourse();
	}
	@Test
	public void testDClickAngularBeginners()
	{
		locating.clickAngularBeginners();
	}
	@
	@Test
	public void testEclickCheckBox()
	{
		locating.clickCheckBox();
		locating.
	}
	
	

}
