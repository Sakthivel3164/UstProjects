package ebayTest;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import ebayLocating.EbayPO;

public class TestEbay {

	WebDriver driver;
	EbayPO ebay;

	@BeforeClass
	public void setup() {
		ChromeOptions options = new ChromeOptions();
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
//		options.addArguments("--start-maximise");

		driver = new ChromeDriver(options);
		driver.manage().window().maximize();

		driver.get("https://www.ebay.com");
		ebay = new EbayPO(driver);
	}
//	@Test
//	public void testEmptySearch()
//	{
//		ebay.selectSearch("");
//		System.out.println(driver.getCurrentUrl()+"null");
//		System.out.println();
//	}

	@Test
	public void testASearchBox() {

		ebay.selectSearch("Selenium");
		System.out.println(driver.getCurrentUrl() + "Not null");

	}

	@Test
	public void testBCategoires() {
		ebay.selectCategory();
	}

	@Test
	public void testClickSearch() {
		ebay.clickSearch();

	}

	@Test
	public void testDclickButIt() {
		ebay.clickBuyIt();

	}

	@Test
	public void testEclickNewlyListed() {

		ebay.clickNewlyListed();
	}
	
	@Test
	public void testFDate()
	{
		ebay.getDate();
		String mon = ebay.getDate();
		
		if(mon.equalsIgnoreCase("sep"))
			System.out.println(true);
		else
			System.out.println(false);
		
		
	}

}
