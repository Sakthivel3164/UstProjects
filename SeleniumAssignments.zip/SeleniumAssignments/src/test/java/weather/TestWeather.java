package weather;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import junkins.JunkinDocumentationPo;
import junkins.JunkinGuidedTourPo;
import junkins.JunkinsPo;

public class TestWeather {
	WebDriver driver;
	WeatherPo po;

	int screenShotCounter;

	@BeforeClass
	public void setup() {
		EdgeOptions options = new EdgeOptions();
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		options.addArguments("--disable-notifications");
		driver = new EdgeDriver(options);
		driver.manage().window().maximize();

		driver.get(" https://weather.com");
		po = new WeatherPo(driver);
	}

	@Test(priority = 0)
	public void testSearch() {
		po.searchBengaluru("Bengaluru");
	}

	@Test(priority = 1)
	public void testClickTenDays() throws InterruptedException {
		po.clickTenDaysLink();
	}

	@Test(priority = 2)

	public void testClickMoreForecast() throws InterruptedException {
		po.clickMoreForecast();
	}

	@Test(dependsOnMethods  = "testClickMoreForecast")
	public void testScrollToAirIndex() {
		
		po.scrollToAirIndex();
	}
	
	@Test(priority = 3)
	public void testClickAirIndex() throws InterruptedException
	{
		assertTrue(po.clickAirIndex().equals("Levels"), "Not clicked");
	}
	
	@AfterMethod
	private void takeScreenshot(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			 screenShotCounter++;
			try {
				FileUtils.copyFile(screenshot,
						new File(System.getProperty("user.dir") + "/screenshots/" + screenShotCounter + ".jpg"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}


}
