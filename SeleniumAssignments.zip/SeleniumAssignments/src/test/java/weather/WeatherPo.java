package weather;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WeatherPo {
	WebDriver driver;
	WebDriverWait wait;

	public WeatherPo(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		PageFactory.initElements(driver, this);

	}

//	Search box
	@FindBy(id = "LocationSearch_input")
	WebElement searchBox;

//	select bengaluru karnataka
	@FindBy(id = "LocationSearch_listbox-f5720f935015d866abbc8f4d5beefe74b16a77fe84928669d117dd882d7de136")
	WebElement bengaluruKarnataka;

//	10 days link
	@FindBy(linkText = "10 Day")
	WebElement tenDays;

//	more forecast
	@FindBy(xpath = "(//button[@data-testid=\"ctaButton\"])[2]")
	WebElement moreForecast;
	@FindBy(linkText = "Video")
	WebElement video;

//	air forecast
	@FindBy(linkText = "Air Quality Forecast")
	WebElement airForecastControl;

//	airindex
	@FindBy(xpath = "//button[@class=\"Button--default--2gfm1 AirQuality--moreDetails--3G8xv\"]")
	WebElement airIndex;
	
//	text in air index
	@FindBy(xpath = "//h4")
	WebElement levelsText;

	public void searchBengaluru(String s) {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		searchBox.sendKeys(s);
		wait.until(ExpectedConditions.elementToBeClickable(bengaluruKarnataka));
		bengaluruKarnataka.click();

	}

	public void clickTenDaysLink() throws InterruptedException {
		Thread.sleep(3000);
		tenDays.click();
		Thread.sleep(4000);

	}

//	click moreforecast
	public void clickMoreForecast() throws InterruptedException {
		wait.until(ExpectedConditions.elementToBeClickable(moreForecast));
		moreForecast.click();

		airForecastControl.click();
		Thread.sleep(3000);
	}

//	Scroll down and click air index
	public void scrollToAirIndex() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,800)", "");
	}

//	click airindex
	public String clickAirIndex() throws InterruptedException {
		airIndex.click();
		wait.until(ExpectedConditions.visibilityOf(levelsText));
		return levelsText.getText();
	}

}
