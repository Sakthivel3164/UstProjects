package ustTest;

import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.internal.annotations.ITest;

import ustCareers.CareersPo;

public class TestCareers {
	WebDriver driver;
	CareersPo po;
	int screenShotCounter;

	@BeforeClass
	public void setup() {
		EdgeOptions options = new EdgeOptions();
		options.addArguments("guest");
		driver = new EdgeDriver(options);
		driver.manage().window().maximize();

		driver.get("https://www.ust.com/en/careers");
		po = new CareersPo(driver);
	}

//	@AfterMethod
//	private void takeScreenshot(ITestResult result) {
//		if (result.getStatus() == ITestResult.FAILURE) {
//			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//			 screenShotCounter++;
//			try {
//				FileUtils.copyFile(screenshot,
//						new File(System.getProperty("user.dir") + "/screenshots/" + screenShotCounter + ".jpg"));
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}
//	}

	@Test
	public void testAAUrl() {
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.ust.com/en/careers", "Incorrect Url");
	}

	@Test
	public void testAClickCookies() {
		po.clickCookies();
	}

	@Test
	public void testBClickIndiaCareers() {
		po.clickIndiaCareers();
	}

	@Test
	public void testCSearchJob() {
		po.searchTestAutomation("test automation");
	}

	@Test
	public void testDLocation() {
		po.locationTrivandrum();
	}

	@Test
	public void testEExperience() {
		po.selectExperince();
	}

	@Test
	public void testFclickJobSearchButton() {
		po.clickJobSearchButton();
	}

	@Test
	public void testGValidateLocation() {
		boolean loc = po.validateLocationFromJobs();
		assertTrue(loc, "Case Failed");

	}
	@Test
	public void testHValidExperience()
	{
		po.validateExperience();
	}
}
