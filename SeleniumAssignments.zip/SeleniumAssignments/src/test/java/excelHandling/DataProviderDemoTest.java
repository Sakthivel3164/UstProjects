package excelHandling;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import angularLocating.AngularLocating;
import browserSetup.BrowserSetup;
import browserSetup.Screenshot;

public class DataProviderDemoTest {
	WebDriver driver;
	
	

//	@DataProvider(name = "Book2")
//	public String[][] getData() throws Exception {
//		String path = System.getProperty("user.dir") + "/resources/Book1.xlsx";
//		String sheetName = "Sheet1";
//		return ExcelHandling2.getExcelData(path, sheetName);
//	}
//
//	@Test(dataProvider = "Book1")
//	public void dataProvider(String username, String password) throws IOException {
//	
//		driver = BrowserSetup.bSetup("chrome");
//
//		driver.get("https://www.saucedemo.com/");
//		driver.findElement(By.id("user-name")).sendKeys(username);
//		driver.findElement(By.id("password")).sendKeys(password);
//
//	}
	
	@Test
	public void testLoginUsingInvalidUserName(String username, String password) throws InterruptedException
	{
		driver = BrowserSetup.bSetup("chrome");

		driver.get("https://www.saucedemo.com/");
		driver.findElement(By.id("user-name")).sendKeys("sakthi");
		driver.findElement(By.id("password")).sendKeys("2727");
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(1000);
		String s = driver.findElement(By.cssSelector("h3")).getText();
		System.out.println(s);
		
		
		
//		assertTrue(s.equals("Epic sadface: Username and password do not match any user in this service"),"Failed");

	}

//	@AfterMethod
//	public void takeScreenShot() {
//		Screenshot.takeScreenshot(driver);
//	}

}