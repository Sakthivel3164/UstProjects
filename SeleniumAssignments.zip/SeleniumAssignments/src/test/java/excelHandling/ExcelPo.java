package excelHandling;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ExcelPo {
	WebDriver driver;
	
	public ExcelPo(WebDriver driver)
	{
		this.driver  =driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(id="user-name")
	WebElement user;
	@FindBy(id="password")
	WebElement pass;
	
	@FindBy(id="login-button")
	WebElement button;
	
	@FindBy(css = "h3[data-test='error']")
	WebElement text;
	
	@FindBy(className = "title")
	WebElement productHeading;
	
	@FindBy(css="h3")
	WebElement nullLoginMessage;
	
	public String login(String uname,String pwd) throws InterruptedException
	{
		user.sendKeys(uname);
		Thread.sleep(1000);
		pass.sendKeys(pwd);
		Thread.sleep(1000);
		button.click();
		Thread.sleep(1000);
		return text.getText();
	}
	
	public String validLogin(String uname,String pwd) throws InterruptedException
	{
		user.sendKeys(uname);
		Thread.sleep(1000);
		pass.sendKeys(pwd);
		Thread.sleep(1000);
		button.click();
		Thread.sleep(1000);
		return productHeading.getText();
	}
	public String nullLogin() throws InterruptedException
	{
		button.click();
		Thread.sleep(1000);
		return nullLoginMessage.getText();
		
	}

}
