package excelHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelHandling {
	@Test
	public String[][] excelHandling() throws Exception {

		FileInputStream fileInputStream = new FileInputStream(
				"C:\\Users\\268845\\Documents\\UnitTesting\\SeleniumAssignments\\resources\\Book2.xlsx");
//			apache poi - handle excel file
//			xlxs-XSSFworkbook
//			xls - HSSFworkbook --->poi library

		Workbook workbook = new XSSFWorkbook(fileInputStream);
		Sheet sheet = workbook.getSheet("Sheet1");
		int rowCount = sheet.getPhysicalNumberOfRows();// to get used row count
		Row row = sheet.getRow(0);
		int colCount = row.getPhysicalNumberOfCells();
		String[][] arr = new String[rowCount][colCount];
//			System.out.println("User Name");
		for (int i = 0; i < rowCount; i++) {
			row = sheet.getRow(i);
			colCount = row.getPhysicalNumberOfCells();
			for (int j = 0; j < colCount; j++) {
				arr[i][j] = row.getCell(j).getStringCellValue();
				System.out.print(arr[i][j] + " ");

			}
			System.out.println();

		}
		return arr;
		// to get used cell count
//			System.out.println("Total number of rows used: "+rowCount);
//			System.out.println("Total number of columns: "+colCount);

	}

}
