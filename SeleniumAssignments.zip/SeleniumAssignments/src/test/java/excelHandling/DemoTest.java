package excelHandling;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import angularLocating.AngularLocating;

public class DemoTest {
	WebDriver driver;
	@BeforeMethod
	public void setup() {
		ChromeOptions options = new ChromeOptions();
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		options.addArguments("--disable-notifications");
		options.addArguments("--start-maximise");
		driver = new ChromeDriver(options);
//		driver.manage().window().maximize();

		driver.get("https://angular-university.io/ ");
	}

}
