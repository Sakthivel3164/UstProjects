package excelHandling;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import browserSetup.BrowserSetup;

public class ExcelTest {
	WebDriver driver;
	ExcelPo po;

	@BeforeMethod
	public void init() {
		driver = BrowserSetup.bSetup("chrome");
		driver.get("https://www.saucedemo.com/");
		 po = new ExcelPo(driver);
	}

	@DataProvider(name = "valid")
	public String[][] getValidData() throws Exception {
		String path = System.getProperty("user.dir") + "/resources/Book2.xlsx";
		String sheetName = "Sheet1";
		return ExcelHandling2.getExcelData(path, sheetName);
	}
	
	@DataProvider(name = "invalid")
	public String[][] getInvalidData() throws Exception {
		String path = System.getProperty("user.dir") + "/resources/Book2.xlsx";
		String sheetName = "Sheet2";
		return ExcelHandling2.getExcelData(path, sheetName);
	}

	@Test(dataProvider = "invalid")
	public void testInavlidLogin(String username, String password) throws IOException, InterruptedException {
		
		String s = po.login(username, password);
		assertTrue(s.equals("Epic sadface: Username and password do not match any user in this service"), "Failed");
		assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/");

	}
	@Test(dataProvider = "valid")
	public void testValidLogin(String uname,String pwd) throws InterruptedException
	{
		String s = po.validLogin(uname, pwd);
		assertTrue(s.equals("Products"), "Login unsuccesful");
		assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/inventory.html");
		
	}
	@Test
	public void testNullLogin() throws InterruptedException
	{
		String s = po.nullLogin();
		assertTrue(s.equals("Epic sadface: Username is required"),"Failed");
		assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/");
		
	}
	

}
