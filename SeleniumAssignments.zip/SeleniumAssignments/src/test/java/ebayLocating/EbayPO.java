package ebayLocating;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EbayPO {
	WebDriver driver;
	WebDriverWait wait;

	public EbayPO(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}

	@FindBy(xpath = "//input[@type=\"text\"]")
	public WebElement searchBox;

	public void selectSearch(String s) {
		searchBox.click();
		searchBox.sendKeys(s);

	}

	@FindBy(css = "select[id='gh-cat']")
	public WebElement categories;

	public void selectCategory() {
		Select s = new Select(categories);
		s.selectByIndex(4);
	}

	@FindBy(id = "gh-btn")
	public WebElement button;

	public void clickSearch() {
		button.click();
	}

	@FindBy(linkText = "Buy It Now")
	public WebElement buyIt;

	public void clickBuyIt() {

		wait.until(ExpectedConditions.visibilityOf(buyIt));

		buyIt.click();

	}
	@FindBy(css="button[class='fake-menu-button__button btn btn--small btn--secondary'][aria-label='Sort selector. Best Match selected.']")
	public WebElement sort;
	
	@FindBy(linkText = "Time: newly listed")
	WebElement newlyListed;
	
	public void clickNewlyListed()
	{
//		wait.until(ExpectedConditions.elementToBeClickable(clickNewlyListed));
		sort.click();
		newlyListed.click();
//		JavascriptExecutor js = (JavascriptExecutor)driver;
//		js.executeScript("clickNewlyListed.aria-expanded=true");
	}
	
	@FindBy(xpath = "//*[@id=\"item34a22c0345\"]/div/div[2]/div[3]/span[1]/span/span")
	WebElement date;
	
	public String getDate()
	{
		String[] month = date.getText().split("-");
		return month[0];
	}
	
	
	
}
