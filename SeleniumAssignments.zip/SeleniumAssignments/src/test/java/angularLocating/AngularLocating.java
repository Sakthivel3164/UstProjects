package angularLocating;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AngularLocating {
	WebDriver driver;
	WebDriverWait wait;

	public AngularLocating(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);

	}
	@FindBy(linkText = "My Courses")
	WebElement myCourse;
	
	@FindBy(className = "course-logo-background")
	WebElement angularBeginners;
	
	@FindBy(xpath = "//tr[1]/td[1]/lesson-viewed-checkbox")
	WebElement checkBox;
	
	public void clickMyCourse()
	{
		myCourse.click();
		myCourse.is
	}
	public void clickAngularBeginners()
	{
		angularBeginners.click();
	}
	public void clickCheckBox()
	{
		checkBox.click();
		Select s = new Select(angularBeginners);
	s.get
	}

}
