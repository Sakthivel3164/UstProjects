package myntraLocating;

import java.time.Duration;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Myntra {
	WebDriver driver;
	WebDriverWait wait;

	public Myntra(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);

	}

//	locate searchbar
	@FindBy(xpath =  "//*[@id=\"desktop-header-cnt\"]/div[2]/div[3]/input")
	WebElement searchBar;

//	locate search button
	@FindBy(className = "desktop-submit")
	WebElement searchButton;
	
//	locate what's new
	@FindBy(xpath = "//*[@id=\"desktopSearchResults\"]/div[1]/section/div[1]/div[1]/div/div/div")
	private WebElement holdElement;
	@FindBy(xpath = "//*[@id=\"desktopSearchResults\"]/div[1]/section/div[1]/div[1]/div/div/div/ul/li[2]")
	private WebElement newoption;
	
	@FindBy(xpath = "//*[@id=\"desktopSearchResults\"]/div[2]/section/ul/li[1]/a/div[2]/h3")
	WebElement productName;

//	enter headphone in searchbar and search
	public void searchBluetoothHeadphone(String s) {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		searchBar.click();
		searchBar.sendKeys(s);
		searchButton.click();
	}
	public void clickWhatsNew()
	{
		
		wait.until(ExpectedConditions.visibilityOf(holdElement));
		holdElement.click();
		newoption.click();
	}
	public String checkProductName()
	{
		wait.until(ExpectedConditions.visibilityOf(productName));
		return productName.getText();
		
	}

}
