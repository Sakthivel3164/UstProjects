package junkins;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JunkinsPo {
	WebDriver driver;
	WebDriverWait wait;

	public JunkinsPo(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);

	}
	
//	find document button
	@FindBy(xpath = "//a[@class=\"btn btn-secondary m-1\"]")
	WebElement documentButton;
	
//	click document button
	public JunkinDocumentationPo clickDocumentButton()
	{
		documentButton.click();
		return new JunkinDocumentationPo(driver);
		
	}

}
