package junkins;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JunkinDocumentationPo {
	WebDriver driver;
	WebDriverWait wait;

	public JunkinDocumentationPo(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);

	}
//	locate documentation page heading
	
	@FindBy(xpath = "//h1")
	WebElement heading;
	
//	guided tour
	@FindBy(xpath = "//ul[2]/li[1]/a[1]")
	WebElement guidedTour;
	
	public String isDashboardHeading()
	{
		return heading.getText();
	}
//	click guided tour
	public JunkinGuidedTourPo clickGuidedTour()
	{
		guidedTour.click();
		return new JunkinGuidedTourPo(driver);
	}
	

}
