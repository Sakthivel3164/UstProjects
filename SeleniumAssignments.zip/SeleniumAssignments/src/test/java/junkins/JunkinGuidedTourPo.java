package junkins;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JunkinGuidedTourPo {
	WebDriver driver;
	WebDriverWait wait;

	public JunkinGuidedTourPo(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);

	}

//	heading 
	@FindBy(xpath = "//h1")
	WebElement heading;

//	was this helpful link
	@FindBy(xpath = "//a[@data-bs-toggle=\"collapse\"]")
	WebElement wasThisHelpful;

//	submit button
	@FindBy(xpath = "//input[@value=\"Submit\"]")
	WebElement submitButton;

//	radio button Yes
	@FindBy(xpath = "//input[@value=\"Yes\"]")
	WebElement radioButtonYes;

//	radio button no
	@FindBy(xpath = "//input[@value=\"No\"]")
	WebElement radioButtonNo;

//	text about textbox
	@FindBy(id = "ssTestLabel")
	WebElement labelTextArea;

//	text area

	@FindBy(id = "ssTestValue")
	WebElement textArea;

//	thank you for feedback
	@FindBy(id = "thank-you-for-your-feedback")
	WebElement thankyouText;

//	validate whether on correct page

	public String isGuidedTour() {
		return heading.getText();
	}

//	click was this helpful link
	public void clickWasThisLinkHelpful() {
		wasThisHelpful.click();
	}
//	check if the button is present or not

	public boolean isSubmitButtonDisplayed() {
		wait.until(ExpectedConditions.visibilityOf(submitButton));
		return submitButton.isDisplayed();
	}

//	Check if radio buttons are present
	public boolean isRadioButtonPresent() {
		return radioButtonNo.isDisplayed() && radioButtonYes.isDisplayed();
	}

//	Check if radio buttons are clickable
	public boolean isRadioButtonClickable() {
		radioButtonYes.click();
		return radioButtonYes.isEnabled();
	}

//	enter text in textarea

	public void enterTextInTextArea() {
		String[] arr = labelTextArea.getText().split(" ");
		int a = Integer.parseInt(arr[4]) + Integer.parseInt(arr[6]);

		textArea.sendKeys(Integer.toString(a));
	}

//	click submit button

	public void clickSubmitButton() {
		submitButton.click();
	}
	public String isThankyouFeedbackDisplayed()
	{
		wait.until(ExpectedConditions.visibilityOf(thankyouText));
		return thankyouText.getText();
	}

}
