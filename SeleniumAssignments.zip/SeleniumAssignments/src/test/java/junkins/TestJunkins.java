package junkins;

import static org.testng.Assert.assertTrue;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestJunkins {
	WebDriver driver;
	JunkinsPo po;
	JunkinDocumentationPo jpo;
	JunkinGuidedTourPo jgpo;
	int screenShotCounter;

	@BeforeClass
	public void setup() {
		ChromeOptions options = new ChromeOptions();
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		options.addArguments("--disable-notifications");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();

		driver.get("https://www.jenkins.io ");
		po = new JunkinsPo(driver);
	}

	@Test(priority = 0)
	public void TestClickDocumentButton() {
		jpo = po.clickDocumentButton();
		assertTrue(jpo.isDashboardHeading().equalsIgnoreCase("Jenkins User Documentation"), "Wrong Page");

	}

	@Test(priority = 1)
	public void TestClickGuidedtour() {
		jgpo = jpo.clickGuidedTour();
		assertTrue(jgpo.isGuidedTour().equalsIgnoreCase("Getting started with the Guided Tour"), "Wrong Page");

	}

	@Test(priority = 2)
	public void TestClickWasThisLinkHelpful() {
		jgpo.clickWasThisLinkHelpful();
		assertTrue(jgpo.isSubmitButtonDisplayed(), "Button Not displayed");
		assertTrue(jgpo.isRadioButtonPresent(), "Radio button not present");
		assertTrue(jgpo.isRadioButtonClickable(), "Button is not clicking");

	}

	@Test(priority = 3)
	public void TestEnterValidDetails() {
		jgpo.isRadioButtonClickable();

		jgpo.enterTextInTextArea();
		jgpo.clickSubmitButton();
		assertTrue(jgpo.isThankyouFeedbackDisplayed().equalsIgnoreCase("Thank you for your feedback!"),"THank you feedback page not displayed");
	}
	
	@AfterMethod
	private void takeScreenshot(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			 screenShotCounter++;
			try {
				FileUtils.copyFile(screenshot,
						new File(System.getProperty("user.dir") + "/screenshots/" + screenShotCounter + ".jpg"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
