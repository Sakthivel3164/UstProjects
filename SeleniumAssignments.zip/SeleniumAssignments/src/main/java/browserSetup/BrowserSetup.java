package browserSetup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class BrowserSetup {

	public static WebDriver bSetup(String s) {

		if (s.equalsIgnoreCase("chrome")) {
			ChromeOptions options = new ChromeOptions();
			System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
			options.addArguments("Disable notifications");
			options.addArguments("start maximized");
//			options.addArguments("--headless");
			options.addArguments("guest");

			WebDriver driver = new ChromeDriver(options);
			return driver;
		} else if (s.equalsIgnoreCase("edge")) {

			EdgeOptions edgeOptions = new EdgeOptions();
			System.setProperty("webdriver.edge.driver", null);
			WebDriver driver2 = new EdgeDriver(edgeOptions);
			return driver2;
		}

		else{ {
			FirefoxOptions firefoxOptions = new FirefoxOptions();
			WebDriver driver3 = new FirefoxDriver(firefoxOptions);
			return driver3;
		}
		}
		
	}

}
