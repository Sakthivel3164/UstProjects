package endpoints;

public class Routes {

	public static String baseUri="https://dummy.restapiexample.com/";
	public static String get_list="api/v1/employees";
	public static String get_single="api/v1/employee/{id}";
	public static String post_user="api/v1/create";
	public static String put="api/v1/update/{id}";
	public static String delete="api/v1/delete/{id}";
	public static String baseUrii="api/v1/employee/1";
}
