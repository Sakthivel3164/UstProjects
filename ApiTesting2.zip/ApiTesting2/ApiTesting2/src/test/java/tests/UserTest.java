package tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import org.testng.ITestListener;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.Routes;
import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.Usermodel;
import utilities.ExtentReportsListener;

@Listeners(utilities.ExtentReportsListener.class)
public class UserTest {

	public Usermodel userPayload;

	@Test
	public void getSingleUser() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.getSingleUser(1);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

	@Test
	public void getListUsers() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.getUserlist();
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

	@Test
	public void deleteUser() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.deleteUser(2);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 204);
	}

	@Test
	public void postUser() {
		Usermodel userPayload1 = new Usermodel();
		userPayload1 = new Usermodel(21, "test", 123, 23, "");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.createUser(userPayload1);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 201);
	}

	@Test
	public void putUser() {
		Usermodel userPayload2 = new Usermodel();
		userPayload2 = new Usermodel(21, "test", 123, 23, "");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.updateUser(21, userPayload2);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

	@Test
	public void schemavalidation() {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given().baseUri(Routes.baseUri).basePath(Routes.baseUrii).when().get().then().assertThat()
//	        .body(matchesJsonSchema(new File("C:\\Users\\268860\\Desktop\\Java\\ApiTesting2\\src\\test\\resources\\payload\\schema.json")));
				.body(matchesJsonSchema(
						new File(System.getProperty("user.dir") + "src\\test\\resources\\payload\\schema.json")));

	}
}
