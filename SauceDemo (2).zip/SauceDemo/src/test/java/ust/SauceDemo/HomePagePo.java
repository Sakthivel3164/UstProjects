package ust.SauceDemo;

import java.time.Duration;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ReusableFunctions;

public class HomePagePo {
	WebDriver driver;
	WebDriverWait wait;
	ReusableFunctions functions;

	public HomePagePo(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		functions = new ReusableFunctions(driver);

	}

//filter button
	@FindBy(className = "product_sort_container")
	WebElement filter;
//	tshirt add to cart button
	@FindBy(id = "add-to-cart-test.allthethings()-t-shirt-(red)")
	WebElement tshirtToCart;
//	onesie add to cart button
	@FindBy(id = "add-to-cart-sauce-labs-onesie")
	WebElement onesieToCart;

	@FindBy(id = "add-to-cart-sauce-labs-backpack")
	WebElement backpack;
//	cart button
	@FindBy(className = "shopping_cart_link")
	WebElement cartButton;
//	All items in home page
	@FindBy(className = "inventory_item_name")
	List<WebElement> items;

//	remove button of tshirt
	@FindBy(id = "remove-test.allthethings()-t-shirt-(red)")
	WebElement removeTshirtButton;

//	checkout button
	@FindBy(id = "checkout")
	WebElement chekcOutButton;

	@FindBy(id = "react-burger-menu-btn")
	WebElement menuButton;
	@FindBy(id = "reset_sidebar_link")
	WebElement resetAppState;

	@FindBy(id = "react-burger-cross-btn")
	WebElement crossButton;

//clicks the filter z to a and validates whether the items are in descending 
//	order or not
	public boolean clickFilter() throws InterruptedException {
		boolean flag = true;
		List<WebElement> asc = items;
		Collections.reverse(asc);

		Thread.sleep(1000);
		Select s = new Select(filter);
		s.selectByIndex(1);
		for (int i = 0; i < asc.size(); i++) {
			if (!asc.get(i).getText().equals(items.get(i).getText())) {
				flag = false;
				break;
			}

		}

		return flag;

	}

// add two items to the cart
	public void addToCart() {
		functions.clickTwoButton(tshirtToCart, onesieToCart);
	}

//click the cart button and check if there are only 2 items
	public boolean clickCartButton() throws InterruptedException {
		functions.clickOnElement(cartButton);
		Thread.sleep(1000);
		return items.size() == 2;

	}

	public boolean removeItem() {
		functions.clickOnElement(removeTshirtButton);
		return items.size() == 1;
	}

	public CheckoutInfoPo clickCheckoutButton() {
		functions.clickOnElement(chekcOutButton);
		return new CheckoutInfoPo(driver);
	}

//	add item after coming back to home page
	public void addToCartAgain() {
		functions.clickOnElement(backpack);

	}

	public void clickMenuButton() {
		functions.waitForElementToDisplay(menuButton);
		functions.clickOnElement(menuButton);
	}

	public Boolean clickResetAppState() {
		functions.waitForElementToDisplay(resetAppState);
		functions.clickOnElement(resetAppState);
		functions.clickOnElement(crossButton);

		return items.size() == 0;

	}

}
