package ust.SauceDemo;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ReusableFunctions;

public class CheckoutInfoPo {
	WebDriver driver;
	WebDriverWait wait;
	ReusableFunctions functions;

	public CheckoutInfoPo(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		functions = new ReusableFunctions(driver);

	}

	@FindBy(id = "first-name")
	WebElement firstName;

	@FindBy(id = "last-name")
	WebElement lastName;

	@FindBy(id = "postal-code")
	WebElement postalCode;

	@FindBy(id = "continue")
	WebElement continueButton;
	@FindBy(css = "h3")
	WebElement errorMessage;

//	public CheckOutOverviewPo enterValidUserCheckoutDetails(String fname, String lname, String pcode) {
//		functions.setTextToInputField(firstName, fname);
//		functions.setTextToInputField(lastName, lname);
//		functions.setTextToInputField(postalCode, pcode);
//		functions.clickOnElement(continueButton);
//
//		return new CheckOutOverviewPo(driver);
//
//	}
	public String getErrorMessage()
	{
		return functions.returnText(errorMessage);
	}
	public CheckOutOverviewPo enterValidUserCheckoutDetails(String fname, String lname, String pcode) {
		functions.setTextToInputField(firstName, fname);
		functions.setTextToInputField(lastName, lname);
		functions.setTextToInputField(postalCode, pcode);
		functions.clickOnElement(continueButton);

		return functions.returnText(errorMessage);

	}

	public void enterDetails(String fname, String lname, String pcode)
	{
		functions.setTextToInputField(firstName, fname);
		functions.setTextToInputField(lastName, lname);
		functions.setTextToInputField(postalCode, pcode);
//		return functions.returnText(errorMessage);
	}
	public void clickContinueButton()
	{
		functions.clickOnElement(continueButton);
	}
	public String nullCheckoutDetails() {
		functions.clickOnElement(continueButton);
		functions.waitForElementToDisplay(errorMessage);
		return functions.returnText(errorMessage);
	}
	public String  nullFirstName(String lname, String pcode)
	{
		functions.setTextToInputField(lastName, lname);
		functions.setTextToInputField(postalCode, pcode);
		functions.clickOnElement(continueButton);
		functions.waitForElementToDisplay(errorMessage);
		return functions.returnText(errorMessage);
	}
	public String  nullLastName(String fname, String pcode)
	{
		functions.setTextToInputField(firstName, fname);
		functions.setTextToInputField(postalCode, pcode);
		functions.clickOnElement(continueButton);
		functions.waitForElementToDisplay(errorMessage);
		return functions.returnText(errorMessage);
	}
	public String  nullPostalCode(String fname, String lname)
	{
		functions.setTextToInputField(firstName, fname);
		functions.setTextToInputField(lastName, lname);
		functions.clickOnElement(continueButton);
		functions.waitForElementToDisplay(errorMessage);
		return functions.returnText(errorMessage);
	}
	

}
