package ust.SauceDemo;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ReusableFunctions;

public class LoginPo {
	WebDriver driver;
	WebDriverWait wait;
	ReusableFunctions functions;

	public LoginPo(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		functions = new ReusableFunctions(driver);

	}

	@FindBy(id = "user-name")
	WebElement user;
	@FindBy(id = "password")
	WebElement pass;

	@FindBy(id = "login-button")
	WebElement button;

	@FindBy(className = "title")
	WebElement productHeading;

	@FindBy(xpath  = "//h3")
	WebElement nullMessage;

	public HomePagePo Login(String username, String pwd) {
		functions.setTextToInputField(user, username);
		functions.setTextToInputField(pass, pwd);
		functions.clickOnElement(button);
		return new HomePagePo(driver);

	}

//	Login for Null Username and null password
	public void nullLogin() {
		functions.clickOnElement(button);
	}
	public void nullUserName(String pwd)
	{
		functions.setTextToInputField(pass, pwd);
		functions.clickOnElement(button);
	}
	public void nullPassword(String userName)
	{
		functions.setTextToInputField(user, userName);
		functions.clickOnElement(button);
	}

//	after successful login get text of product heading element
	public String getHomePageText() {
		return functions.returnText(productHeading);
	}

//	get the text after invalid login
	public String getInvalidLoginText() {
		return functions.returnText(nullMessage);
	}

}
