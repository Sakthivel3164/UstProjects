package step_definition.addToCart;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;

import base.ReusableFunctions;
import io.cucumber.java.en.Then;
import step_definition.login.LoginTest;
import ust.SauceDemo.HomePagePo;

public class AddToCartTest {

	public static WebDriver driver = LoginTest.driver;
	HomePagePo homePagePo = new HomePagePo(driver);
	ReusableFunctions rf =  new ReusableFunctions(driver);
	

	@Then("user filters the product in z-a order")
	public void user_filters_the_product_in_z_a_order() throws InterruptedException {
		assertTrue(homePagePo.clickFilter(), "Failed");

	}

	@Then("user add  products to cart")
	public void user_add_products_to_cart() {
		homePagePo.addToCart();

	}

	@Then("user click on the cart button")
	public void user_click_on_the_cart_button() throws InterruptedException {

		assertTrue(homePagePo.clickCartButton());

	}

	@Then("user validates products in cart")
	public void user_validates_products_in_cart() {
		assertTrue(homePagePo.removeItem());

	}

	@Then("user clicks the checkout button")
	public void user_clicks_the_checkout_button() {
		homePagePo.clickCheckoutButton();
	}

	@Then("user already on checkout page")
	public void user_already_on_checkout_page() {
		assertEquals(driver.getCurrentUrl(), rf.getval("checkouturl"));

	}

}
