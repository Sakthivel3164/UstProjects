package step_definition.checkout;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import base.ReusableFunctions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import step_definition.addToCart.AddToCartTest;
import step_definition.login.LoginTest;
import ust.SauceDemo.CheckoutInfoPo;

public class CheckoutTest {
	
	static WebDriver driver = AddToCartTest.driver;
	CheckoutInfoPo checkoutInfoPo = new CheckoutInfoPo(driver);
	ReusableFunctions rf =  new ReusableFunctions(driver);
	
	@When("user input {string} as firstname {string} as lastname {string} as postalcode")
	public void user_input_as_firstname_as_lastname_as_postalcode(String string, String string2, String string3) {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   checkoutInfoPo.enterDetails(string, string2, string3);
	   
	}

	@And("user click continue button")
	public void user_click_continue_button() {
	    checkoutInfoPo.clickContinueButton();
	}

	@Then("user is already on checkout info page")
	public void user_is_already_on_checkout_info_page() {
	    assertEquals(driver.getCurrentUrl(), rf.getval("checkoutoverviewurl"));
	}


}
