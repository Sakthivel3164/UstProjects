package ust.SauceDemo;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ListenresDemo implements ITestListener {
	public void onsStart(ITestContext context) {
		

	}
	public void onTestStart(ITestResult iTestResult)
	{
		
		
	}
	public void onTestSuccess(ITestResult result)
	{
		
	}
	public void onTestFailure(ITestResult result)
	{
		
	}
	public void onTestSkipped(ITestResult result)
	{
		
	}
	public void onFinish(ITestResult result)
	{
		
	}

}
