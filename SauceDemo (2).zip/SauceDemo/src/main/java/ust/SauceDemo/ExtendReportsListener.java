package ust.SauceDemo;

import org.testng.ITestContext;
import org.testng.ITestListener;

public class ExtendReportsListener implements ITestListener {
	
		public void onStart(ITestContext context  )
		{
			
	}

}
