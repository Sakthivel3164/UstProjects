package ust.SauceDemo;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ReusableFunctions;

public class CheckOutOverviewPo {
	WebDriver driver;
	WebDriverWait wait;
	ReusableFunctions functions;

	public CheckOutOverviewPo(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		functions = new ReusableFunctions(driver);

	}

//individual item price
	@FindBy(className = "inventory_item_price")
	WebElement itemPrice;
//total item price
	@FindBy(className = "summary_subtotal_label")
	WebElement itemTotal;
	@FindBy(className = "summary_tax_label")
	WebElement tax;
	@FindBy(className = "summary_total_label")
	WebElement sumTotalTax;
	@FindBy(id = "finish")
	WebElement finishButton;
	@FindBy(css = "h2")
	WebElement thankyouMsg;
	@FindBy(id = "back-to-products")
	WebElement backToHomeButton;

	public boolean validateCost() {
		String itemcost = functions.returnText(itemPrice);
		String totalcost = functions.returnText(itemTotal).split(" ")[2];
		return itemcost.equals(totalcost);
	}

	public boolean validateSumOfTotalCostAndTax() {
		String totalcost = functions.returnText(itemTotal).split("[\\s$]")[3];
		String tax1 = functions.returnText(tax).split("[\\s$]")[2];
		String total = functions.returnText(sumTotalTax).split("[\\s$]")[2];

		return Double.parseDouble(totalcost) + Double.parseDouble(tax1) == Double.parseDouble(total);

	}

	public String clickFinishButton() {
		functions.clickOnElement(finishButton);
		functions.waitForElementToDisplay(thankyouMsg);
		return functions.returnText(thankyouMsg);
	}

	public void clickBackToHomeButton() {
		functions.clickOnElement(backToHomeButton);
	}

}
