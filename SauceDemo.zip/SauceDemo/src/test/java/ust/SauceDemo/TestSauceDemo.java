package ust.SauceDemo;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import base.ReusableFunctions;

public class TestSauceDemo {
	WebDriver driver;
	LoginPo loginPo;
	HomePagePo homePagePo;
	CheckoutInfoPo infoPo;
	CheckOutOverviewPo overviewPo;
	ReusableFunctions rf;
//	ExtentSparkReporter htmlReporter;
	ExtentReports reports;
	ExtentTest test;

	
	@BeforeClass
	public void invokeBrowser() {

		driver = ReusableFunctions.invokeBrowser();
		loginPo = new LoginPo(driver);
		ReusableFunctions.openWebsite("url");
		rf = new ReusableFunctions(driver);

	}
	@BeforeTest
	public void startReport() {
		reports = ReusableFunctions.generateReport("ExtendReport.html");
	}

	@AfterMethod
	public void getTestResult(ITestResult result) {
		rf.getTestResult(result,test);
	}

	

	@Test(priority = 0)
	public void testNullUsernameAndNullPassword() throws InterruptedException {
		test = reports.createTest("Login with emty inputs");
		loginPo.nullLogin();

		assertTrue(loginPo.getInvalidLoginText().equals(rf.getval("noUserNameMessage")), "Failed");
		assertEquals(driver.getCurrentUrl(), rf.getval("url"));

	}

//	
	@Test(priority = 1)
	public void testNullPassword() throws InterruptedException {
		test = reports.createTest("Null password");
		loginPo.nullPassword(rf.getval("vname"));
		assertEquals(loginPo.getInvalidLoginText(), rf.getval("noPwdMessage"));
		assertEquals(driver.getCurrentUrl(), rf.getval("url"));

	}

	@Test(priority = 2)
	public void testNullUsername() throws InterruptedException {
		test = reports.createTest("Null user name");
		driver.navigate().refresh();

		loginPo.nullUserName(rf.getval("ipwd"));
		assertTrue(loginPo.getInvalidLoginText().equals(rf.getval("noUserNameMessage")), "Failed");
		assertEquals(driver.getCurrentUrl(), rf.getval("url"));

	}

	@Test(priority = 3)
	public void testInvalidLogin() {
		test = reports.createTest("Invalid login details");
		driver.navigate().refresh();
		loginPo.Login(rf.getval("iname"), rf.getval("ipwd"));

		assertTrue(loginPo.getInvalidLoginText().equals(rf.getval("invalidMessage")), "Failed");
		assertEquals(driver.getCurrentUrl(), rf.getval("url"));

	}

	@Test(priority = 4)
	public  void testValidLogin() {
		test = reports.createTest("Valid login");
		driver.navigate().refresh();
		homePagePo = loginPo.Login(rf.getval("vname"), rf.getval("vpwd"));
		assertTrue(loginPo.getHomePageText().equals(rf.getval("homePageTitle")), "Not moved to new page");
		assertEquals(driver.getCurrentUrl(), rf.getval("homePageUrl"));
	}

	@Test(priority = 5)
	public void testClickFilter() throws InterruptedException {
		test = reports.createTest("Click filter");
		assertTrue(homePagePo.clickFilter(), "Failed");

	}

	@Test(priority = 6)
	public void testClickAddToCart() throws InterruptedException {
		test = reports.createTest("Click add to cart");
		homePagePo.addToCart();

		assertTrue(homePagePo.clickCartButton(), "Failed");
		assertEquals(driver.getCurrentUrl(), rf.getval("carturl"));
	}

	@Test(priority = 7)
	public void testRemoveOneItemFromCart() {
		test = reports.createTest("Remove item from cart");
		assertTrue(homePagePo.removeItem(), "failed");
	}

	@Test(priority = 8)
	public void testClickCheckoutButton() {
		test = reports.createTest("Click checkout button");
		infoPo = homePagePo.clickCheckoutButton();
		assertEquals(driver.getCurrentUrl(), rf.getval("checkouturl"));
	}

	@Test(priority = 9)
	public void testNullCheckoutUserDetails() {
		test = reports.createTest("Login with emty inputsull checkout details");
		assertEquals(infoPo.nullCheckoutDetails(), rf.getval("nofirstNameMsg"));
	}

	@Test(priority = 10)
	public void testNullFirstNameInCheckoutUserDetails() {
		test = reports.createTest("Null first name");
		driver.navigate().refresh();
		String s = infoPo.nullFirstName(rf.getval("lastname"), rf.getval("postalcode"));
		assertEquals(s, rf.getval("nofirstNameMsg"));
	}

	@Test(priority = 11)
	public void testNullLastNameInCheckoutUserDetails() {
		test = reports.createTest("Null last name");
		driver.navigate().refresh();
		String s = infoPo.nullLastName(rf.getval("firstname"), rf.getval("postalcode"));
		assertEquals(s, rf.getval("noLastNameMsg"));
	}

	@Test(priority = 12)
	public void testNullPostalCodeInCheckoutUserDetails() {
		test = reports.createTest("Null Postal Code");
		driver.navigate().refresh();
		String s = infoPo.nullPostalCode(rf.getval("firstname"), rf.getval("lastname"));
		assertEquals(s, rf.getval("noPostalCodeMsg"));
	}

	@Test(priority = 13)
	public void testValidateUserCheckoutDetails() {
		test = reports.createTest("Validta euser checkout details");
		overviewPo = infoPo.enterValidUserCheckoutDetails(rf.getval("firstname"), rf.getval("lastname"),
				rf.getval("postalcode"));
		assertEquals(driver.getCurrentUrl(), rf.getval("checkoutoverviewurl"));
	}

	@Test(priority = 14)
	public void testvalidateSumOfProductCostEqualToTotalCost() {
		test = reports.createTest("Validate sum of product cost");
		assertTrue(overviewPo.validateCost(), "Failed");
	}

	@Test(priority = 15)
	public void testValidateSumOfTotalPlusTax() {
		test = reports.createTest("Validate sum of total and tax");
		assertTrue(overviewPo.validateSumOfTotalCostAndTax(), "Failed");
	}

	@Test(priority = 16)
	public void testClickFinishButton() {
		test = reports.createTest("Click Finsih Button");
		String s = overviewPo.clickFinishButton();
		assertEquals(s, rf.getval("thankyouMsg"));
		assertEquals(driver.getCurrentUrl(), rf.getval("thankyouUrl"));
	}

	@Test(priority = 17)
	public void testClickBackToHome() {
		test = reports.createTest("click Back to home button");
		overviewPo.clickBackToHomeButton();
		assertEquals(driver.getCurrentUrl(), rf.getval("homePageUrl"));
	}

	@Test(priority = 18)
	public void testClickAddToCartAgain() throws InterruptedException {
		test = reports.createTest("Add to cart Again");
		homePagePo.addToCartAgain();
		homePagePo.clickCartButton();
		homePagePo.clickMenuButton();
		boolean flag = homePagePo.clickResetAppState();
		assertTrue(flag, "Failed");

	}
	@AfterTest
	public void tearDown()
	{
		reports.flush();
	}

}
