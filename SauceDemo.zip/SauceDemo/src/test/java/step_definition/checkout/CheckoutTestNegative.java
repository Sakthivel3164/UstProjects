package step_definition.checkout;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;

import base.ReusableFunctions;
import io.cucumber.java.en.Then;
import step_definition.addToCart.AddToCartTest;
import ust.SauceDemo.CheckoutInfoPo;

public class CheckoutTestNegative {

	static WebDriver driver = AddToCartTest.driver;
	CheckoutInfoPo checkoutInfoPo = new CheckoutInfoPo(driver);
	ReusableFunctions rf = new ReusableFunctions(driver);

//	@Then("user get {string} as error message")
//	public void user_get_as_error_message(String string) {
//		assertEquals(string, checkoutInfoPo.getErrorMessage());
//	}
}
