package step_definition.login;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;

import base.ReusableFunctions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import ust.SauceDemo.HomePagePo;
import ust.SauceDemo.LoginPo;

public class LoginTest {
	public static WebDriver driver;
	LoginPo loginPo;
	ReusableFunctions rf;

	@Given("User already open website sauce demo")
	public void user_already_open_website_sauce_demo() {

		driver = ReusableFunctions.invokeBrowser();
		loginPo = new LoginPo(driver);
		ReusableFunctions.openWebsite("url");
		rf = new ReusableFunctions(driver);
//		
	}

	@When("User input {string} as username {string} as password")
	public void user_input_as_username_as_password(String string, String string2) {
		loginPo.Login(string, string2);

	}

	@Then("user already on homepage")
	public void user_already_on_homepage() {
		assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/inventory.html");
	}

}
