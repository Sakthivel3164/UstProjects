package step_definition.login;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Then;
import ust.SauceDemo.LoginPo;

public class LoginInvalidTest {
	WebDriver driver;
	LoginPo loginPo  = new LoginPo(LoginTest.driver);
	
	@Then("User get {string} as error message")
	public void user_get_as_error_message(String string) {
		assertEquals(string, loginPo.getInvalidLoginText());
		

	}

}
