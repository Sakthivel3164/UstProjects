package ust.SauceDemo;

import org.testng.annotations.Test;

public class ListenerTestCase {
	@Test
	public  ListenerTestCase()
	{
		
	}

}
